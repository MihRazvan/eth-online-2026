# FeeStrip synthetic Ethereum proof experiment

Executed 2026-09-11. **9 Solidity tests passed, including one fuzz test with 128 cases.** Five independent Python proof checks passed before generating the Solidity fixture.

This validates a bounded account/storage proof integration against independently generated synthetic Ethereum-style tries. It is **not** a live Ethereum RPC proof, deployed FeeStrip transaction, authenticated block-header experiment, Uniswap integration test, security audit or full settlement benchmark.

## What was tested

- py-trie constructed an account trie containing 25 accounts and a storage trie containing 83 nonzero slots.
- The target used a hashed 20-byte address and hashed 32-byte storage slots. The selected raw slots follow the v4 pool/tick layout derivation, but their values are synthetic and no actual Uniswap contract executes here.
- One account proof authenticates the storage root and expected code hash. A deduplicated multiproof returns four storage values, including valid non-membership representing zero.
- Solidity results equal the independent Python trie results.
- Wrong state root, wrong account, wrong code hash, altered account/storage nodes and missing storage nodes are rejected.
- A wrong storage path cannot alias the selected nonzero fee-growth value; this was also fuzzed across 128 random keys.

`ProofHarness.prove` deliberately accepts its state root and requested slots as arguments. A real settlement adapter MUST authenticate the root from the agreed canonical block and derive permitted slots itself. These application-level restrictions are not supplied by a generic trie verifier and are not tested here.

## Measured synthetic cost

The gasleft measurement around one external call verifying the account plus four slots was **1,212,180 gas**. It includes the call/ABI overhead within that measured expression but excludes fixture construction before the measurement. The whole test reports 1,221,142 gas.

Proof nodes contain 543 bytes for the account and 1,291 bytes for the deduplicated storage multiproof: **1,834 raw proof-node bytes**, excluding ABI framing and all header data. Independent storage proofs would contain 2,887 bytes before deduplication.

This is one small synthetic trie shape. It is not an upper bound, average Ethereum cost, user fee estimate or full FeeStrip settlement cost. There is no header authentication, checkpoint write, historical fee calculation, collection, claim finalization or token transfer in this benchmark. This result is sufficient to show that proof-verification gas deserves explicit optimization and amortization work; calling this approach cheap would be premature.

## Reproduction

Python dependencies used: trie 4.0.0, rlp 5.0.0 and eth-hash 0.8.0 with a working Keccak backend. Current workspace command:

```bash
PYTHONPATH=/workspace/scratch/b162aa2fd442/tmp/feestrip_pydeps python generate_fixtures.py
/workspace/scratch/b162aa2fd442/tmp/feestrip_tools/forge test -vv --gas-report
```

`foundry.toml` points to the installed local Solidity compiler. Change that path or set `solc = "0.8.26"` in a different environment. Foundry version was 1.8.1, commit 982849d3140c01fd3b72905759581a132df7aa98. Solidity 0.8.26, optimizer 200 runs, via IR. The raised test-contract code-size limit permits embedded proof fixtures and does not demonstrate deployability of a full protocol.

## Source provenance

Vendored `lib/polytope` source was downloaded at commit **6bbc83d5ac33f85761725cf2eba4f8700164e8ba** from [Polytope solidity-merkle-trees](https://github.com/polytope-labs/solidity-merkle-trees). Its Apache-2.0 license is preserved. EthereumTrie and its Ethereum trie decoder are used. New research harness files are MIT licensed via their SPDX headers; they are experimental, unaudited code.

The first local run had one test-fixture assertion fail because XORing the selected slot with 1 selected an adjacent EXISTING slot. The verifier correctly returned that slot's value. The test was corrected to request a distinct absent slot and the full nine-test suite passed. This was a harness mistake, not a discovered verifier bug.

Files: `generate_fixtures.py` is the independent producer; `fixtures.json` preserves roots, slots, values and raw proofs; `test/Fixtures.sol` embeds them; `src/ProofHarness.sol` is the verifier consumer; `test/ProofHarness.t.sol` contains adversarial checks; `test_output.txt` preserves the successful Foundry run.
