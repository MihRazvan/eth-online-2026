// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;

import {EthereumTrie} from "polytope/EthereumTrie.sol";
import {StorageValue} from "polytope/trie/Node.sol";
import {RLPReader} from "polytope/trie/ethereum/RLPReader.sol";

/// @notice Research harness. State root supplied by caller; NO header authentication here.
contract ProofHarness {
    using RLPReader for bytes;
    using RLPReader for RLPReader.RLPItem;
    function prove(bytes32 stateRoot, address account, bytes32 expectedCodeHash,
        bytes32[] memory rawSlots, bytes[] memory accountProof, bytes[] memory storageProof)
        external pure returns (uint256[] memory result)
    {
        bytes[] memory accountKeys = new bytes[](1);
        accountKeys[0] = abi.encodePacked(keccak256(abi.encodePacked(account)));
        StorageValue[] memory provenAccounts = EthereumTrie.VerifyProof(stateRoot, accountProof, accountKeys);
        require(provenAccounts[0].value.length != 0, "account absent");
        RLPReader.RLPItem[] memory fields = provenAccounts[0].value.toRlpItem().toList();
        require(fields.length == 4, "account shape");
        require(fields[2].toBytes().length == 32 && fields[3].toBytes().length == 32, "root width");
        require(bytes32(fields[3].toUint()) == expectedCodeHash, "code hash mismatch");
        bytes32 storageRoot = bytes32(fields[2].toUint());
        bytes[] memory storageKeys = new bytes[](rawSlots.length);
        for (uint256 i; i < rawSlots.length; ++i) storageKeys[i] = abi.encodePacked(keccak256(abi.encodePacked(rawSlots[i])));
        StorageValue[] memory provenSlots = EthereumTrie.VerifyProof(storageRoot, storageProof, storageKeys);
        result = new uint256[](rawSlots.length);
        for (uint256 i; i < rawSlots.length; ++i) {
            // Only successful authenticated absence produces empty bytes. No catch/revert-to-zero.
            if (provenSlots[i].value.length != 0) result[i] = provenSlots[i].value.toRlpItem().toUint();
        }
    }
}
