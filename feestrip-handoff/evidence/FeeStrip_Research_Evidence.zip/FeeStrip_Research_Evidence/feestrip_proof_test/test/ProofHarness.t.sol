// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;
import {ProofHarness} from "../src/ProofHarness.sol";
import {Fixtures} from "./Fixtures.sol";

contract ProofHarnessTest {
    ProofHarness harness;
    event log_named_uint(string key, uint256 value);
    function setUp() public { harness = new ProofHarness(); }
    function testSyntheticAccountAndFourSlotsIncludingZero() public {
        bytes[] memory ap = Fixtures.accountProof();
        bytes[] memory sp = Fixtures.storageProof();
        bytes32[] memory slots = Fixtures.slots();
        uint256 beforeGas = gasleft();
        uint256[] memory actual = harness.prove(Fixtures.STATE_ROOT, Fixtures.ACCOUNT, Fixtures.CODE_HASH, slots, ap, sp);
        uint256 used = beforeGas - gasleft();
        emit log_named_uint("synthetic_account_plus_four_slots_external_call_gas", used);
        uint256[] memory wanted = Fixtures.values();
        for (uint256 i; i < wanted.length; ++i) require(actual[i] == wanted[i], "differential mismatch");
        require(actual[2] == 0, "valid exclusion should read zero");
    }
    function testWrongStateRootRejected() public {
        _mustReject(bytes32(uint256(Fixtures.STATE_ROOT)^1), Fixtures.ACCOUNT, Fixtures.CODE_HASH, Fixtures.slots(), Fixtures.accountProof(), Fixtures.storageProof());
    }
    function testWrongAccountRejected() public {
        _mustReject(Fixtures.STATE_ROOT, address(uint160(Fixtures.ACCOUNT)^1), Fixtures.CODE_HASH, Fixtures.slots(), Fixtures.accountProof(), Fixtures.storageProof());
    }
    function testWrongCodeHashRejected() public {
        _mustReject(Fixtures.STATE_ROOT, Fixtures.ACCOUNT, bytes32(uint256(Fixtures.CODE_HASH)^1), Fixtures.slots(), Fixtures.accountProof(), Fixtures.storageProof());
    }
    function testTamperedAccountNodeRejected() public {
        bytes[] memory ap=Fixtures.accountProof(); ap[0][10]=bytes1(uint8(ap[0][10])^1);
        _mustReject(Fixtures.STATE_ROOT, Fixtures.ACCOUNT, Fixtures.CODE_HASH, Fixtures.slots(), ap, Fixtures.storageProof());
    }
    function testTamperedStorageRootNodeRejected() public {
        bytes[] memory sp=Fixtures.storageProof(); sp[0][10]=bytes1(uint8(sp[0][10])^1);
        _mustReject(Fixtures.STATE_ROOT, Fixtures.ACCOUNT, Fixtures.CODE_HASH, Fixtures.slots(), Fixtures.accountProof(), sp);
    }
    function testMissingStorageNodesRejectedInsteadOfZero() public {
        bytes[] memory original=Fixtures.storageProof(); bytes[] memory truncated=new bytes[](1);truncated[0]=original[0];
        _mustReject(Fixtures.STATE_ROOT, Fixtures.ACCOUNT, Fixtures.CODE_HASH, Fixtures.slots(), Fixtures.accountProof(), truncated);
    }
    function testWrongStoragePathCannotClaimPresentValue() public {
        bytes32[] memory slots=Fixtures.slots(); slots[1]=keccak256("unrelated absent storage slot");
        try harness.prove(Fixtures.STATE_ROOT, Fixtures.ACCOUNT, Fixtures.CODE_HASH, slots, Fixtures.accountProof(), Fixtures.storageProof()) returns(uint256[] memory actual) {
            require(actual[1]==0, "wrong path must not alias genuine value");
        } catch {}
    }
    function testFuzzWrongKeyNeverAliasesValue(bytes32 wrongSlot) public {
        bytes32[] memory slots=Fixtures.slots(); if (wrongSlot==slots[1]) return;
        slots[1]=wrongSlot;
        try harness.prove(Fixtures.STATE_ROOT, Fixtures.ACCOUNT, Fixtures.CODE_HASH, slots, Fixtures.accountProof(), Fixtures.storageProof()) returns(uint256[] memory actual) {
            require(actual[1]!=123456789, "wrong path aliases selected fee growth");
        } catch {}
    }
    function _mustReject(bytes32 root,address account,bytes32 codeHash,bytes32[] memory slots,bytes[] memory ap,bytes[] memory sp) internal view {
        bool rejected;
        try harness.prove(root,account,codeHash,slots,ap,sp) returns(uint256[] memory) {} catch { rejected=true; }
        require(rejected,"invalid witness unexpectedly accepted");
    }
}
