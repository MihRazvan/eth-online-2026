// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {Pool} from "../lib/v4-core/src/libraries/Pool.sol";
import {Position} from "../lib/v4-core/src/libraries/Position.sol";
import {TickMath} from "../lib/v4-core/src/libraries/TickMath.sol";
import {FullMath} from "../lib/v4-core/src/libraries/FullMath.sol";
import {Slot0} from "../lib/v4-core/src/types/Slot0.sol";
import {BalanceDelta, BalanceDeltaLibrary} from "../lib/v4-core/src/types/BalanceDelta.sol";

interface Vm {
    function snapshotState() external returns (uint256);
    function revertToState(uint256 snapshotId) external returns (bool);
    function roll(uint256 newHeight) external;
}

/// @dev Exercises real pinned Uniswap v4 Pool/Position math, not copied fee math.
/// Pool library tests do NOT exercise ERC20 transfer settlement, NFT custody,
/// header/MPT verification, or deployed-manager bytecode. Currency0 stands for
/// the sold fee leg; these amounts are raw token units, not price estimates.
contract FeeStripNativeAccountingTest {
    using Pool for Pool.State;
    using Position for mapping(bytes32 => Position.State);
    using BalanceDeltaLibrary for BalanceDelta;

    Vm constant vm = Vm(address(uint160(uint256(keccak256("hevm cheat code")))));
    uint256 constant Q128 = 1 << 128;
    int24 constant LOWER = -120;
    int24 constant UPPER = 120;
    uint128 constant SUBJECT_L = 2e18;
    bytes32 constant SUBJECT_SALT = bytes32(uint256(1));
    Pool.State private pool;

    event log_named_uint(string key, uint256 val);

    function setUp() public {
        pool.initialize(uint160(1 << 96), 3000);
        pool.modifyLiquidity(Pool.ModifyLiquidityParams({
            owner: address(this), tickLower: -600, tickUpper: 600,
            liquidityDelta: 5e18, tickSpacing: 60, salt: bytes32(uint256(2))
        }));
        pool.modifyLiquidity(Pool.ModifyLiquidityParams({
            owner: address(this), tickLower: LOWER, tickUpper: UPPER,
            liquidityDelta: int128(SUBJECT_L), tickSpacing: 60, salt: SUBJECT_SALT
        }));
    }

    function _position() internal view returns (Position.State storage p) {
        p = pool.positions.get(address(this), LOWER, UPPER, SUBJECT_SALT);
    }

    function _swap(bool zeroForOne, uint128 amount) internal {
        pool.swap(Pool.SwapParams({
            amountSpecified: -int256(uint256(amount)), tickSpacing: 60,
            zeroForOne: zeroForOne,
            sqrtPriceLimitX96: zeroForOne ? TickMath.MIN_SQRT_PRICE + 1 : TickMath.MAX_SQRT_PRICE - 1,
            lpFeeOverride: 0
        }));
    }

    function _collect() internal returns (uint256 fee0, uint256 fee1) {
        (BalanceDelta principal, BalanceDelta fees) = pool.modifyLiquidity(Pool.ModifyLiquidityParams({
            owner: address(this), tickLower: LOWER, tickUpper: UPPER,
            liquidityDelta: 0, tickSpacing: 60, salt: SUBJECT_SALT
        }));
        require(principal.amount0() == 0 && principal.amount1() == 0, "principal moved");
        require(fees.amount0() >= 0 && fees.amount1() >= 0, "negative native fees");
        return (uint128(fees.amount0()), uint128(fees.amount1()));
    }

    function _liability(uint256 inside, uint256 baseline, uint128 liquidity) internal pure returns (uint256) {
        unchecked { return FullMath.mulDiv(inside - baseline, liquidity, Q128); }
    }

    // Equivalent computation from the four maturity storage values which a
    // historical proof would authenticate. Uses the stored tick, not sqrtPrice.
    function _fourLeafInside0() internal view returns (uint256 result) {
        uint256 low = pool.ticks[LOWER].feeGrowthOutside0X128;
        uint256 high = pool.ticks[UPPER].feeGrowthOutside0X128;
        int24 tick = pool.slot0.tick();
        unchecked {
            if (tick < LOWER) return low - high;
            if (tick >= UPPER) return high - low;
            return pool.feeGrowthGlobal0X128 - low - high;
        }
    }

    function test_DelayedCollectionMatchesNativeMaturityAndConservesLiquidity() public {
        uint256 baseline = _position().feeGrowthInside0LastX128;
        _swap(true, 1e16);
        _swap(false, 7e15);
        vm.roll(100);
        (uint256 insideN,) = pool.getFeeGrowthInside(LOWER, UPPER);
        uint256 liability = _liability(insideN, baseline, SUBJECT_L);
        uint256 snap = vm.snapshotState();
        (uint256 nativeAtN,) = _collect();
        require(liability == nativeAtN && liability > 0, "wrong maturity entitlement");
        require(vm.revertToState(snap), "snapshot restore failed");
        vm.roll(130);
        _swap(true, 5e15);
        pool.donate(1000, 2000);
        (uint256 collected0, uint256 collected1) = _collect();
        uint256 lpRemainder = collected0 - liability;
        require(collected0 > liability, "post maturity accrual missing");
        require(liability + lpRemainder == collected0, "fee conservation failed");
        require(_position().liquidity == SUBJECT_L, "liquidity changed");
        emit log_named_uint("claim_currency0_at_N", liability);
        emit log_named_uint("total_currency0_captured_later", collected0);
        emit log_named_uint("lp_currency0_remainder", lpRemainder);
        emit log_named_uint("lp_all_currency1", collected1);
        emit log_named_uint("unchanged_liquidity", _position().liquidity);
    }

    function test_InitialPokeExcludesPreSaleFees() public {
        _swap(true, 1e16);
        (uint256 oldFees,) = _collect();
        require(oldFees > 0, "missing pre sale fees");
        uint256 baseline = _position().feeGrowthInside0LastX128;
        _swap(true, 4e15);
        (uint256 inside,) = pool.getFeeGrowthInside(LOWER, UPPER);
        uint256 liability = _liability(inside, baseline, SUBJECT_L);
        (uint256 newFees,) = _collect();
        require(liability == newFees && newFees > 0, "checkpoint wrong");
        require(oldFees + newFees > liability, "old fees inadvertently sold");
    }

    function test_AllThreeTickBranchesAndNoFeesOutsideRange() public {
        (uint256 inside,) = pool.getFeeGrowthInside(LOWER, UPPER);
        require(pool.slot0.tick() >= LOWER && pool.slot0.tick() < UPPER, "not initially inside");
        require(_fourLeafInside0() == inside, "inside branch wrong");

        _swap(true, 1e17);
        require(pool.slot0.tick() < LOWER, "did not cross lower");
        (uint256 below,) = pool.getFeeGrowthInside(LOWER, UPPER);
        require(_fourLeafInside0() == below, "below branch wrong");
        pool.donate(1e9, 0);
        _swap(true, 1e16);
        (uint256 belowAfter,) = pool.getFeeGrowthInside(LOWER, UPPER);
        require(belowAfter == below, "out of range position earned fees");

        _swap(false, 2e17);
        require(pool.slot0.tick() >= UPPER, "did not cross upper");
        (uint256 above,) = pool.getFeeGrowthInside(LOWER, UPPER);
        require(_fourLeafInside0() == above, "above branch wrong");
        pool.donate(1e9, 0);
        (uint256 aboveAfter,) = pool.getFeeGrowthInside(LOWER, UPPER);
        require(aboveAfter == above, "out of range donation accrued");
    }

    function test_ExactLowerBoundaryUsesStoredTickNotPriceDerivedTick() public {
        uint160 boundary = TickMath.getSqrtPriceAtTick(LOWER);
        pool.swap(Pool.SwapParams({
            amountSpecified: -int256(1e18), tickSpacing: 60, zeroForOne: true,
            sqrtPriceLimitX96: boundary, lpFeeOverride: 0
        }));
        require(pool.slot0.sqrtPriceX96() == boundary, "not exact boundary");
        require(pool.slot0.tick() == LOWER - 1, "native stored tick mismatch");
        require(TickMath.getTickAtSqrtPrice(boundary) == LOWER, "price tick mismatch");
        // Outside donation changes G while the subject is inactive. Mistakenly
        // using the price-derived tick falsely counts it as in range.
        (uint256 correctBefore,) = pool.getFeeGrowthInside(LOWER, UPPER);
        pool.donate(1e12, 0);
        (uint256 correctAfter,) = pool.getFeeGrowthInside(LOWER, UPPER);
        require(correctAfter == correctBefore, "native boundary accounting changed");
        uint256 wrong;
        unchecked {
            wrong = pool.feeGrowthGlobal0X128 - pool.ticks[LOWER].feeGrowthOutside0X128
                - pool.ticks[UPPER].feeGrowthOutside0X128;
        }
        require(wrong != correctAfter, "bad tick computation was not exposed");
    }

    function test_NativeEntitlementIncludesDonations() public {
        uint256 baseline = _position().feeGrowthInside0LastX128;
        pool.donate(7e12, 0);
        (uint256 inside,) = pool.getFeeGrowthInside(LOWER, UPPER);
        uint256 predicted = _liability(inside, baseline, SUBJECT_L);
        (uint256 actual,) = _collect();
        require(actual == predicted && actual > 0, "donation not included");
        emit log_named_uint("fee_claim_from_donation_without_swap", actual);
    }

    function test_InterimCollectionInvalidatesSingleCheckpointAssumption() public {
        uint256 startBaseline = _position().feeGrowthInside0LastX128;
        _swap(true, 1e16);
        (uint256 alreadyCollected,) = _collect();
        _swap(true, 5e15);
        (uint256 inside,) = pool.getFeeGrowthInside(LOWER, UPPER);
        uint256 incorrectUnfundedLiability = _liability(inside, startBaseline, SUBJECT_L);
        (uint256 remaining,) = _collect();
        require(alreadyCollected > 0 && incorrectUnfundedLiability > remaining,
            "did not expose forbidden poke");
    }

    function testFuzz_DelayedAllocationConservesNativeReceipts(uint64 beforeAmount, uint64 afterAmount) public {
        uint128 first = uint128(uint256(beforeAmount) % 1e16 + 10000);
        uint128 later = uint128(uint256(afterAmount) % 1e16 + 10000);
        uint256 baseline = _position().feeGrowthInside0LastX128;
        _swap(true, first);
        (uint256 insideN,) = pool.getFeeGrowthInside(LOWER, UPPER);
        uint256 liability = _liability(insideN, baseline, SUBJECT_L);
        uint256 snap = vm.snapshotState();
        (uint256 nativeAtN,) = _collect();
        require(nativeAtN == liability, "fuzz native checkpoint mismatch");
        require(vm.revertToState(snap), "snapshot failed");
        _swap(true, later);
        (uint256 captured,) = _collect();
        require(captured >= liability, "fuzz shortfall");
        uint256 remainder = captured - liability;
        require(liability + remainder == captured, "fuzz conservation");
        require(_position().liquidity == SUBJECT_L, "fuzz principal changed");
    }

    function testFuzz_RoundingResidualAssignedWithoutOverclaim(uint128 rawL, uint128 beforeGrowth, uint128 afterGrowth) public pure {
        uint128 liquidity = rawL == 0 ? 1 : rawL;
        uint256 a = uint256(beforeGrowth);
        uint256 b = uint256(afterGrowth);
        uint256 mature = FullMath.mulDiv(a, liquidity, Q128);
        uint256 late = FullMath.mulDiv(a + b, liquidity, Q128);
        uint256 naivePost = FullMath.mulDiv(b, liquidity, Q128);
        require(late >= mature, "rounding underfunded");
        uint256 exactRemainder = late - mature;
        require(exactRemainder == naivePost || exactRemainder == naivePost + 1, "rounding bound");
        require(mature + exactRemainder == late, "rounding conservation");
    }
}
