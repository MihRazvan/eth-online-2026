# FeeStrip native Uniswap accounting feasibility tests

This is a research harness, not production FeeStrip code or a security audit.
It executes the real Uniswap v4 `Pool` and `Position` libraries at pinned core
revision `46c6834698c48bc4a463a86d8420f4eb1d7f3b75` (official GitHub archive).
The dependency source is unmodified and retains its original licenses.

## Run

With Foundry installed:

```sh
forge test -vv
```

In this workspace:

```sh
/workspace/scratch/b162aa2fd442/tmp/feestrip_tools/forge test -vv
```

Compiler: Solidity 0.8.26. EVM: Cancun. Optimizer: 200 runs.
Foundry used: 1.8.1, commit `982849d3140c01fd3b72905759581a132df7aa98`.
Execution evidence: `RESULTS.txt`.

## What passed

Eight tests, zero failures. The two fuzz tests each executed 512 cases.

- Fee liability computed from maturity accumulators equals a native collection
  at that exact state. After restoring the uncollected state and executing
  more swaps/donations, later native collection covers the fixed maturity
  amount. Fees divide exactly into claims and LP remainder; L is unchanged.
- A zero-liquidity poke clears all earlier fees before the sale's baseline.
- The maturity formula works for native below/inside/above tick branches.
  Out-of-range positions do not earn later swap/donation fees.
- At an exact downward crossing, the pool's stored tick is lower-1 while
  the tick recomputed from sqrtPrice is lower. A donation exposes why using
  the latter can produce a wrong fee entitlement.
- A donation, with no swap, creates a native fee entitlement. Endpoint proofs
  therefore cannot distinguish organic trading fees from donated fee growth.
- An interim zero-delta collection invalidates a formula assuming all fees
  since the original baseline are still available. Such pokes must be forbidden
  or explicitly accounted for by the actual protocol.
- Fuzzed delayed accrual remains covered and conserves native receipts.
- Fuzzed floor arithmetic shows why the LP must receive `total - maturity`,
  rather than an independently rounded post-maturity formula.

## What these tests do not establish

- These tests exercise native Pool/Position accounting in the EVM. They do not
  deploy PoolManager/PositionManager, transfer real ERC20s, or take NFT custody.
- Historical state is saved/restored using a Foundry cheatcode for a reference
  native collection at N. This is NOT a cryptographic historical proof test.
- No historical MPT/block-root verification, claims mint/burn/redemption,
  auction, Aqua/SwapVM, malicious NFT subscriber, ERC-1271 custody behavior,
  or upgrade governance is implemented here.
- No mainnet/testnet contract was mutated. Mainnet bytecode equivalence is not
  established. Gas values in RESULTS.txt are harness test gas, not a FeeStrip
  production gas benchmark.
- Currency0 is the designated sold fee leg in the fixtures. Numeric logs use
  raw token units and abstract equal-price liquidity, not a realistic WETH/USDC
  market price or APY. Correct token addresses/decimals belong to integration.

Source references:
- https://github.com/Uniswap/v4-core/tree/46c6834698c48bc4a463a86d8420f4eb1d7f3b75
- https://github.com/Uniswap/v4-core/blob/46c6834698c48bc4a463a86d8420f4eb1d7f3b75/src/libraries/Pool.sol
- https://github.com/Uniswap/v4-core/blob/46c6834698c48bc4a463a86d8420f4eb1d7f3b75/src/libraries/Position.sol

