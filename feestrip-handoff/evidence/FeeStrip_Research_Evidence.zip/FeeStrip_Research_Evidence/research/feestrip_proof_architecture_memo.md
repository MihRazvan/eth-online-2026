# FeeStrip historical settlement — independent technical review

Research date: 2026-09-11. This is a source and architecture review. A subsequent bounded synthetic proof experiment is documented in `feestrip_proof_test/README.md`: 9 Solidity tests passed (including 128 fuzz cases), with independent Python fixture verification. There was no live-chain proof, deployed FeeStrip integration or complete settlement benchmark.

## Verdict

The historical-state construction is technically sound for a same-chain, immutable-liquidity position, assuming a correct MPT verifier and exact custody/accounting invariants. It can determine the position's selected-token fee entitlement through an agreed end block even when collection occurs later. This is a real Ethereum capability, not a new oracle primitive. Robustness depends much more on defining the instrument, controlling the position and maintaining proof availability than on inventing new cryptography.

Recommend Ethereum L1 for the first production architecture, with Sepolia integration tests, an allowlist of PoolManager/PositionManager versions, hookless pools, one selected payout asset, immutable range/liquidity, no intermediate fee collection, and block-number maturity. Other EVM chains require separate history-system and RPC verification.

## Exact boundary and accounting

Record the current fee-growth-inside baseline onchain when opening the claim, after removing pre-existing fees. Hold the NFT in a contract that cannot decrease/increase liquidity, transfer it early, permit third-party operators, or redirect fee proceeds. NFT ownership alone is not enough if previously granted permissions or indirect call paths remain usable.

At agreed end block N, obtain fee-growth-inside from the pool state at the END of that block. Cached per-position last-growth values are updated on position interactions and are not reliable endpoint snapshots. Uniswap's current StateLibrary computes the live inside value from current tick, global growth and lower/upper boundary growth. The fee amount uses the fixed liquidity and the modular endpoint-minus-baseline growth difference with Uniswap-compatible full-precision division/rounding.

The source also shows that Pool.donate changes feeGrowthGlobal. Therefore this claim measures collectable pool fee-growth distributions, including donations. It does not prove that income came from organic trading, or remove wash trading. Define the claim accordingly; excluding donations requires additional accounting and is not provided by four endpoint slots.

Sources: [StateLibrary](https://github.com/Uniswap/v4-core/blob/main/src/libraries/StateLibrary.sol), [Pool](https://github.com/Uniswap/v4-core/blob/main/src/libraries/Pool.sol), [Position](https://github.com/Uniswap/v4-core/blob/main/src/libraries/Position.sol).

## Minimal endpoint witness

Under custody invariants already enforced at creation, a one-token claim needs one account proof for the precise PoolManager and four storage proofs: pool slot0/current tick; selected-token global growth; selected-token lower-bound outside growth; selected-token upper-bound outside growth. Both payout tokens need seven slots. This is a logical minimum for the straightforward formula, not a measured calldata/gas total. A proof may share common trie nodes across slots; don't assume seven independent proofs must repeat all bytes.

Derive storage locations onchain from the fixed pool ID, ticks and pinned layout. Do not accept caller-chosen storage keys or an arbitrary target contract. Validate signed negative ticks with correct sign extension. Ethereum's storage-trie key is the hash of the raw 32-byte storage slot, whereas the account-trie key hashes the 20-byte account address. Know whether the chosen verifier hashes keys itself; double hashing or hashing a 32-byte padded address is wrong.

Slot0 can be nonzero while fee-growth-outside is legitimately zero. Zero Ethereum storage generally requires an exclusion proof. Reject incomplete or malformed proofs; catching a verifier revert and treating it as zero is a critical vulnerability.

[EIP-1186](https://eips.ethereum.org/EIPS/eip-1186) describes account and storage proofs, their roots and absence proofs. The RPC's top-level value/codeHash/storageHash fields must never override values decoded from the verified account and storage nodes.

## Authenticating the state root

1. A permissionless checkpoint records the exact canonical block hash for N while Ethereum still exposes it. Alternatively settlement obtains it directly during the available window.
2. Verify keccak256 of the supplied RLP execution header equals the checkpointed hash.
3. Decode and require the expected block number; obtain the state root from its authenticated header field.
4. Verify the PoolManager account under that state root. Decode its storage root and code hash; compare with the approved version where appropriate.
5. Verify the deterministic storage slots under that storage root and compute the amount.
6. Finalize the specific series once; token redemption consumes claims against that fixed amount.

The header commits to the post-state, not arbitrary intermediate transaction state. A maturity advertised as a wall-clock instant needs a precise rule and, if necessary, authenticated adjacent headers bracketing that instant. A fixed block number is unambiguous; displayed clock time is an estimate.

Authenticate the complete RLP header, including fork-added trailing fields. Don't reconstruct a pre-London 15-field header in 2026. Geth exposes [debug_getRawHeader](https://geth.ethereum.org/docs/interacting-with-geth/rpc/ns-debug); public providers may not expose debug methods. A generator can reconstruct a header using a fork-aware client library, but must verify its hash against eth_getBlockByNumber before submission.

## EIP-2935 materially improves checkpoint liveness

[EIP-2935](https://eips.ethereum.org/EIPS/eip-2935) defines the history system contract at 0x0000F90827F1C53a10cb7A02335B175320002935. A raw 32-byte block-number call retrieves a hash in [current block minus 8191, current block minus 1]. The BLOCKHASH opcode remains limited to 256 ancestors. EIP-2935 is included in [Pectra](https://blog.ethereum.org/2025/04/23/pectra-mainnet), activated on Ethereum mainnet in May 2025 and previously on Sepolia. Deployment and actual call results on the selected chain should still be integration-tested.

The history contract is a ring buffer, not permanent storage and not a state-proof RPC. Store the maturity hash durably before overwrite. Permissionless checkpoints with prepaid rewards and multiple independent operators reduce liveness dependence. Once the hash is stored, endpoint proof submission need not fit that window, provided someone retains the state witness.

If a checkpoint is missed, recovery can authenticate older headers by walking parent hashes backward from a currently trusted header, potentially in chunks. This preserves trust but has linear data/gas cost in distance. A more advanced post-Pectra recovery can use authenticated historical state proofs of the history contract to jump up to 8191 ancestors at a time. Both are architectural possibilities requiring their own test vectors; neither was implemented here. EIP-4788/beacon-state historical accumulators are another recovery route with a substantially different SSZ proof stack.

## Proof availability is distinct from authenticity

The smart contract can reject lies from an RPC provider, but it cannot force the provider to supply a witness. Fetch and persist proofs near each maturity, use multiple providers, and let any holder submit the same authenticated data. Publicly archive raw proof bundles, header and derivation metadata. This is availability infrastructure, not a trusted price oracle.

[Geth's current archive documentation](https://geth.ethereum.org/docs/fundamentals/archive) says hash-based archive nodes retain historical tries. Path-based archive v1.16 did not support historical eth_getProof; v1.17 supports it when historical trie retention is configured. Historical flat-state access or an 'archive' marketing label alone is insufficient. Default historical trie retention is disabled; explicitly test endpoint support and retention for the intended age of proof.

## Canonicality versus finality

A recent authenticated execution hash is an ancestor of the chain executing settlement. It is not an independent proof that consensus has finalized that block. A same-chain reorg also rolls back the settlement built upon it, which is the ordinary Ethereum execution model. A confirmation delay is a policy, not a finalized-checkpoint proof. Do not trust a server's JSON 'finalized' label as contract evidence.

If explicit finalized-state verification becomes a product requirement, [EIP-4788](https://eips.ethereum.org/EIPS/eip-4788) exposes authenticated beacon roots from which additional consensus-state proofs can be built. It does not directly expose the execution state root or make every referenced block finalized.

## Important liveness improvement: release the principal separately

After N, a permitted unwind can collect all selected-token fees earned through collection block S into escrow, then return the underlying NFT while keeping that fee escrow reserved. Once the N proof arrives, buyers get the amount through N and the original LP gets the surplus earned after N. The non-sold token's fees can follow the agreed LP entitlement.

This avoids freezing principal purely because the proof service is late. It is safe only if range/liquidity stayed fixed through collection and collection/escrow accounting is exact. The contract must never release, sweep or lend the unresolved buyer reserve. State after the NFT is returned is irrelevant to the already authenticated historical N state. This is a proposed design improvement, not tested functionality.

## Verifier candidates and provenance

**Polytope Labs solidity-merkle-trees** is the strongest directly relevant candidate identified here: Apache-2.0; EthereumTrie.VerifyProof supports Ethereum MPT values and authenticated absence; Solidity/Rust fuzz-test infrastructure is public. The retrieved repository head is 6bbc83d5ac33f85761725cf2eba4f8700164e8ba, dated 2026-06-26. Its May 11 commit 12f352fb9b0b311bff26df6a6571329d39ad59be is titled 'Audit Fixes' and specifically repairs Ethereum odd-leaf key aliasing and empty-trie behavior. This is a reason to pin and scrutinize the current implementation, not copy old snippets. A complete independent audit mapping to the exact final pin was NOT established in this pass. Hyperbridge has public audits, but that does not automatically establish coverage of every version of this standalone verifier.

[Repository](https://github.com/polytope-labs/solidity-merkle-trees), [pinned EthereumTrie source](https://github.com/polytope-labs/solidity-merkle-trees/blob/6bbc83d5ac33f85761725cf2eba4f8700164e8ba/src/EthereumTrie.sol), [May audit-fix PR](https://github.com/polytope-labs/solidity-merkle-trees/pull/53).

**Optimism SecureMerkleTrie/MerkleTrie** supplies MIT-licensed, maintained inclusion-proof code within a widely reviewed stack. Its API is inclusion-only and fails for absent slots, so it does not meet this application's full requirements without a separately reviewed exclusion implementation. Optimism publishes an audit index with exact scopes and commits; project-wide audit history is not coverage for our integration.

[SecureMerkleTrie](https://github.com/ethereum-optimism/optimism/blob/develop/packages/contracts-bedrock/src/libraries/trie/SecureMerkleTrie.sol), [MerkleTrie](https://github.com/ethereum-optimism/optimism/blob/develop/packages/contracts-bedrock/src/libraries/trie/MerkleTrie.sol), [security reviews](https://github.com/ethereum-optimism/optimism/tree/develop/docs/security-reviews).

## Alternative settlement designs

| Design | What it gives | Material tradeoff |
|---|---|---|
| Historical proof over existing position | Exact past block; supports existing compatible pools | Verifier, witness availability, checkpoint and layout coupling |
| New v4 pool with accounting hook | Stores the needed checkpoints as activity happens | Needs new pool/liquidity; hook costs and new trust surface |
| First keeper collection after maturity | Straightforward current-state collection | Actual cutoff becomes execution time unless product terms explicitly say so |
| Operator/committee signed total | Simple submission interface | Replaces native proof with signer trust; not equivalent |

A custom hook can snapshot the old values before the first fee-changing operation after maturity. It must cover swaps, donations and all other relevant mutation paths, and avoid unbounded iteration over expired positions. Hooks are bound in the pool key; a hook cannot be retrofitted transparently onto an existing hookless pool. [Uniswap hook model](https://developers.uniswap.org/docs/protocols/v4/concepts/hooks).

## Acceptance tests that decide whether this is robust

- Real pinned Uniswap contracts: baseline, in-range/out-of-range growth, crossing both boundaries, zero outside values, negative ticks, no swaps and donations.
- Independently generated proofs at N reconcile with live reads at N and actual later token collection; post-N trading changes only LP surplus.
- Reject wrong block, pool, chain deployment, manager, slot, code/version, root, malformed RLP, wrong trie path, omitted nodes, key aliasing and fabricated absence.
- No double finalization, double redemption, replay across series or unauthorized receiver; supply and payout conservation under fractional transfers and dust.
- Principal cannot escape before maturity and buyer reserve cannot escape after maturity; all delegated permissions and callbacks tested.
- Missed checkpoint recovery or explicit operational guarantee is demonstrated; outage cannot permit an admin to invent an entitlement.
- Measure complete proof bytes, gas, transaction size and marginal cost per extra position against real deployed state. Shared pool endpoints can be cached and amortized. The subsequent synthetic harness measured 1,212,180 gas for one account plus four storage slots, using 1,834 raw proof-node bytes; this is not a live-state or full-settlement estimate.
