# FeeStrip: Aqua / SwapVM feasibility and stack research

Research cutoff: 11 September 2026. This is a source-level assessment, not an executed integration or audit. Aqua — © Degensoft Ltd 2025. SwapVM — © Degensoft Ltd 2025.

## Conclusion

The proposed fee-claim market is technically feasible with Aqua and SwapVM. Use an immutable external pricing instruction that reads FeeStrip's authoritative onchain accounting and calculates claim/USDC amounts. Aqua holds permission records and settles actual ERC20 transfers; it does not hold the Uniswap position, value future fees, ensure buyers exist, or guarantee that an advertised maker balance remains spendable.

Recommended path: pin one exact SwapVM runtime, deploy a reproducible Aqua-compatible router with a small known instruction set, and implement FeeStrip's read-only pricing through `Extruction`. This reuses the sponsor execution engine and settlement while making the bespoke instruction economically relevant. A modified router is explicitly permitted by the bounty. An existing router can also work if its exact ABI, opcode layout and Extruction interface are verified; source and SDK versions currently differ substantially.

Current bounty: [Build an Aqua App](https://ethglobal.com/events/ethonline2026/prizes/1inch): sophisticated custom DeFi position; SwapVM earns stronger consideration; custom instructions and modified SwapVM redeployment allowed; demonstrate real token transfers (local fork accepted); proper commit history. Fresh pool $5,000, distributed $2,500/$1,500/$1,000. This is a strong integration without adding AI or a decorative third sponsor.

## Verified source pins and version mismatch

| Component | Observed version / commit | Evidence and implications |
|---|---|---|
| SwapVM contracts main | `afd99c408b4ed610027f4426c6f98650acac9f5f`, 9 Sep 2026; package version 0.0.6 | [Commit](https://github.com/1inch/swap-vm/commit/afd99c408b4ed610027f4426c6f98650acac9f5f). Solidity 0.8.30, optimizer 700, viaIR. Core currently has four swap registers and quote/order token encoding differs from release/1.1. |
| Aqua main | `9c5c42e5840e8741fba3597c48456c9510212b66`, 21 Aug 2026 | [Commit](https://github.com/1inch/aqua/commit/9c5c42e5840e8741fba3597c48456c9510212b66). Main package version is 0.1.0, which does not itself identify deployment bytecode. |
| Aqua dependency pinned by current SwapVM | tag v1.0.0 resolves to `81c26e4619ce21556ab02b3284ee2685de21fb18`, 17 Mar 2026 | [SwapVM package](https://github.com/1inch/swap-vm/blob/afd99c408b4ed610027f4426c6f98650acac9f5f/package.json). Prefer its tested dependency pin over silently substituting Aqua main. |
| SwapVM release/1.1 branch | `ac06e1bac021cd1983dc7c44d1f69b4b8861a945` | [Release source](https://github.com/1inch/swap-vm/tree/ac06e1bac021cd1983dc7c44d1f69b4b8861a945). Old src layout, five registers including amountNetPulled, explicit tokenIn/tokenOut quote arguments. |
| TypeScript SDK monorepo | `cc4b8c7c646beed8e3dfb2e39597d27f337ea4a7`, 11 Sep 2026 | [Commit](https://github.com/1inch/sdks/commit/cc4b8c7c646beed8e3dfb2e39597d27f337ea4a7). Repository packages aqua-sdk 0.3.3 and swap-vm-sdk 0.4.3; registry publication/install not independently tested. |

Concrete compatibility problem: [current contract OpcodeList](https://github.com/1inch/swap-vm/blob/afd99c408b4ed610027f4426c6f98650acac9f5f/contracts/libs/OpcodeList.sol) assigns Extruction opcode 0x04; [SDK instruction table](https://github.com/1inch/sdks/blob/cc4b8c7c646beed8e3dfb2e39597d27f337ea4a7/typescript/swap-vm/src/swap-vm/instructions/index.ts) still lists it at position 33 in the Aqua table and 34 in the full table. The old and new function selectors differ too. Do not blindly encode the current SDK's defaults against a main-source router.

The [SDK README](https://github.com/1inch/sdks/blob/cc4b8c7c646beed8e3dfb2e39597d27f337ea4a7/typescript/swap-vm/README.md) explicitly warns that SDK instruction coverage differs from deployed runtime coverage. Its hardfork timeline prose is stale and should not be used to infer the current network state. Generate ABI/opcode encoding from the exact deployed commit; compare Solidity and TypeScript golden byte vectors, order hashes and quotes.

## How the external pricing instruction works

[Extruction.sol](https://github.com/1inch/swap-vm/blob/afd99c408b4ed610027f4426c6f98650acac9f5f/contracts/instructions/Extruction.sol) calls a maker-selected external contract and receives the updated program counter, consumed taker-argument length and swap registers. In quote mode it uses a view interface (STATICCALL); in swap mode it uses the same signature through a regular call. It is not a delegatecall into the FeeStrip vault.

Implement FeeStrip's endpoint as `external view` in both modes. Return the incoming program counter unchanged and consume zero dynamic taker arguments. Read only the immutable, approved FeeStrip series and its onchain accounting. Never harvest, checkpoint, settle, mutate inventory, or consult an offchain API inside pricing. Do not branch the amount calculation on isStaticContext. This gives equal numerical results for quote and swap against identical chain state; a later transaction may legitimately face different state or time, so taker thresholds and deadlines remain necessary.

Proposed reader output: authoritative series identifier and terms hash, fixed initial claim supply, start/expiry, accrued USDC attributable to these claims, and whether trading is open. Accrual can combine already collected reserves and exact collectable pool fees if the vault's accounting proves their ownership. Plain `balanceOf(vault)` is insufficient because donations or other series' funds can pollute it. Pool fee growth can itself include Uniswap donate proceeds: label the actual economic entitlement precisely, and do not infer organic volume from it.

Maker-authored immutable strategy data includes series address, quote start/expiry, max inventory, max per-fill size, bid/ask future-fee premiums and any discount on deferred accrued cash. Changing these parameters requires docking and shipping a new salted strategy, not silently updating a centralized price server.

## Proposed pricing and exact rounding

This formula is a suggested executable quote, not a fair-value theorem. Let Q be fixed initial claim-token supply in raw units; C the USDC accrued for the entire series in atomic USDC units; T expiry; t0 strategy creation; U the maker's initial quote for all remaining future fees; d=T-t0. A simple ask is a rational price:

`N = C*d + U*max(T-t,0)`; `D = Q*d`.

For x raw claims, exact-output cost is `ceil(x*N/D)`. For u raw USDC exact input, claims out are `floor(u*D/N)`. The reverse bid uses its own maker-chosen Nbid: claim input -> `floor(x*Nbid/D)` USDC; exact USDC output -> `ceil(u*D/Nbid)` claims input. Use full-precision mulDiv and bounded validated inputs so intermediate N/D construction cannot overflow. Reject zero price, zero output and unsupported pairs. Exact-output always rounds required input up; exact-input always rounds delivered output down. Do not leave decimals to frontend floating-point math.

Uask >= Ubid with a consistent accrued-cash discount yields a noncrossed same-maker spread. If accrued cash is paid only at maturity it can reasonably trade below nominal value due to delay and risk; C/Q is not automatically a cash-arbitrage floor. U can be wrong. Buyers and competing makers price expected order flow, range occupancy, dilution from other LP liquidity, contract risk and time value. Keep expected earnings, earned fees and executable quote visibly separate.

The first robust design can use bounded linear bid/ask orders. A nonlinear inventory curve is optional additional work, not required to establish usefulness. If later added, its pricing must depend on economically controlled inventory, and split-trade behavior and closed-loop profitability must be proved. An ordinary constant-product claim pool is easier but does not showcase the live entitlement update.

## Settlement and funding rules

In [Aqua.sol](https://github.com/1inch/aqua/blob/9c5c42e5840e8741fba3597c48456c9510212b66/src/Aqua.sol), `ship` writes virtual token allowances without moving tokens. `safeBalances` verifies an active strategy and returns that ledger; it does not read real wallet balances or ERC20 approvals. `pull` decrements the ledger then transfers maker tokens; `push` increases the ledger and transfers taker tokens into the maker wallet. A failed transfer reverts the transaction.

Consequences:

- Show executable liquidity as bounded by strategy allowance, actual maker wallet balance, ERC20 allowance and simulation. Shared strategies can over-advertise the same physical capital; never sum all their balances as TVL.
- Makers can spend tokens or revoke approvals between quote and inclusion. This is a fill/liveness risk, not a reason to seize LP collateral.
- The LP position locked in FeeStrip is separate from maker USDC/claim inventory in Aqua. It cannot serve as automatically available secondary-market cash.
- Direct ERC20 approvals authorize Aqua; individual strategies define what the app may pull. Authenticate the exact approved router, series and order bytes.
- Use the current runtime's `useTransferFromAndAquaPush` path for a plain wallet taker; do not require custom taker callbacks for a normal user. It transfers input to the router then pushes it to the maker and verifies settlement. Use explicit amount thresholds, recipient, deadline and exact-mode flags.
- Disable unneeded arbitrary maker hooks/taker callbacks in the endorsed product path, or validate them carefully. Generic router reentrancy protection is per order hash, not a blanket vault/series lock. Cross-order and underlying-pool callbacks need separate lifecycle invariants.
- Close claim-market trading at maturity until final settlement; do not use post-expiry live fee growth as the old series' entitlement. Redemption should be independent of whether a market maker remains online. Fixed issuance Q must not be replaced with shrinking totalSupply after burns when calculating old entitlements.

[SwapVM transfer implementation](https://github.com/1inch/swap-vm/blob/afd99c408b4ed610027f4426c6f98650acac9f5f/contracts/SwapVM.sol); [TakerTraits](https://github.com/1inch/swap-vm/blob/afd99c408b4ed610027f4426c6f98650acac9f5f/contracts/libs/TakerTraits.sol).

## Networks and practical stack

Ethereum is the clearest match when the settlement design depends on Ethereum-specific authenticated historical roots. Aqua/SwapVM advertise Ethereum deployments; official Uniswap lists Ethereum v4 PoolManager `0x000000000004444c5dc75cB358380D2e3dE08A90`. Base and Unichain also have documented Uniswap and 1inch deployments, but availability of all addresses does not prove historical-proof support. Do not transport an L1 blockhash/state-root design to an L2 without separately verifying chain semantics. [Uniswap deployments](https://developers.uniswap.org/docs/protocols/v4/deployments), [SwapVM overview](https://github.com/1inch/swap-vm).

For a persistent testnet, official Uniswap lists Sepolia; the SwapVM deployment guide includes Sepolia constructor-parameter templates, but placeholders are not verified public deployments. Deploy the pinned official/custom router and Aqua as necessary and publish addresses plus code hashes. A pinned Ethereum fork is useful for reproducible integration tests and expressly accepted by 1inch; it should be labeled as a fork. No contracts were deployed or RPC bytecode checked in this research.

Recommended surrounding stack: Solidity/Foundry for FeeStrip invariant and fork tests; pinned Solidity 0.8.30 and matching EVM target for SwapVM; official v4 core/periphery as selected by the position adapter; OpenZeppelin ERC20/SafeERC20/full-precision Math at a compatible pin; TypeScript/viem for reads, simulation and transactions; React/Next plus wallet connector of team preference. Use an event indexer/Postgres for series discovery and maker offers, never as settlement authority.

Useful official SDK operations: AquaProtocolContract.ship/dock, Shipped/Docked/Pulled/Pushed parsing; SwapVMContract.quote/swap/hashOrder and Swapped parsing. The Aqua SDK is a transaction encoder/event decoder, not a ready-made source of counterparties. The SwapVM SDK has ProgramBuilder for custom tables, but exact ABI/encoding validation is required for current main. [Aqua SDK](https://github.com/1inch/sdks/tree/master/typescript/aqua), [SwapVM SDK](https://github.com/1inch/sdks/tree/master/typescript/swap-vm).

## Meaningful verification gates

1. Solidity/TypeScript order hash and program bytes identical for pinned runtime; mismatched old SDK vectors must fail visibly.
2. Quote and swap same amounts against identical snapshot; accrued-fee and timestamp changes cause expected repricing, with min-output/max-input enforcement.
3. All four directions/exact modes tested across 6/18 decimals, tiny amounts, huge bounded values, no free zero-input outputs, maker-favoring rounding, exhausted inventory and split fills.
4. Real claim/USDC transfers update maker/taker balances and Aqua ledgers exactly; neither LP principal nor series reserves move during trading.
5. Revoked allowance, spent maker inventory, docked order, wrong series, expired series and stale terms revert atomically.
6. Malicious hook/callback, cross-order reentry, same-transaction pool donation, claim mint/burn and maturity transition do not create unbacked entitlement or bypass exchange limits.
7. Final redemption works without Aqua, the frontend, indexer or maker. Pricing failure never traps finalized reserves.

## Licensing limitation

Both current repositories and SDKs use custom Degensoft source licenses, not MIT/Apache unrestricted open source. They permit noncommercial experimentation and hackathons subject to modification/source/attribution requirements. Derivative runtime/instruction modifications must preserve the specified license and notices; independent components calling published interfaces are distinguished in the text. The binding commercial clauses are broader than the short summary's $100k-fee/$10m-LUC examples, and the market-making enforcement waiver is expressly revocable. Do not promise commercial freedom below those amounts. Read the chosen pinned license before product commercialization; this observation is about the source dependency, not a full legal opinion. [Aqua license](https://github.com/1inch/aqua/blob/main/LICENSES/Aqua-Source-1.1.txt), [SwapVM license](https://github.com/1inch/swap-vm/blob/main/LICENSES/SwapVM-1.1.txt).
