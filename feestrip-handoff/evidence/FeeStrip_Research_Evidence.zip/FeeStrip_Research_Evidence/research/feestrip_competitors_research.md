# FeeStrip: competitor and economic research

Research cutoff: 11 September 2026. Source/document review; no deployed competitor contracts were independently exercised and no traction figures are asserted. Broad search returned sparse results; that is a limitation, never evidence of worldwide novelty.

## Verdict

Feasible economic instrument: prepaid, non-recourse sale of an exactly defined LP fee stream. This is a specialization of existing yield tokenization, not a new category. The promising niche is a native Uniswap fee claim that separates gross trading-fee income from the position's changing inventory value, gives precise period ownership, and remains tradable with transparent backing. Strongest product-killing risk is economic: sellers sacrifice range-management/exit flexibility worth more than the fee prepayment, while buyers demand a large discount for volume, competition and range risk. Engineering feasibility does not demonstrate a two-sided market.

Do not call it principal protection or fixed-return liquidity. The seller retains LP price/divergence risk and locks custody or management rights. The buyer can lose the entire purchase price. Sell USDC fees initially if desired, but even a USDC-denominated fee stream depends on ETH price paths, trade direction, routing and active liquidity; it is not market-neutral.

## Closest products and usable source material

1. Pendle (current documented protocol): https://docs.pendle.finance/pendle-v2/Introduction . Existing SY -> PT/YT split and yield trading; markets are permissionless, official UI listing is curated. Cannot claim first future-yield marketplace or first principal/yield separation.

2. Pendle SY: https://docs.pendle.finance/pendle-v2/ProtocolMechanics/YieldTokenization/SY . Standardized interfaces, underlying custody, reward distribution and wrappers already handle varied yield mechanics. Do not claim a Uniswap integration is inherently impossible in Pendle; a wrapper is possible subject to asset accounting.

3. Pendle public adapters: https://github.com/pendle-finance/Pendle-SY-Public . README explicitly lists AMM LP tokens (GMX, Thena), plus staking/lending/yield aggregators. Thus 'first LP yield trading' is false as a broad pitch. README license is BUSL-1.1: publicly readable is not the same as unrestricted open source. Useful for adapter and reward-accounting research, check per-file terms before reuse.

4. Pendle negative-yield mechanics: https://docs.pendle.finance/pendle-v2/ProtocolMechanics/NegativeYield . Exchange-rate-based yield is subject to a high watermark; YT can cease earning until recovery. FeeStrip's proposed native fee payout can still increase when LP inventory market value declines. This distinction applies to the accounting design; don't assert every Pendle reward adapter must suspend separately distributed rewards.

5. Pendle discrete yield: https://docs.pendle.finance/pendle-v2/ProtocolMechanics/DiscreteYield . Current documentation treats late payouts and transfers explicitly, including forfeiture of accrued discrete yield when leaving before payout. Valuable precedent that holder-at-payment is not automatically holder-entitled-to-period. FeeStrip should choose a much clearer claim contract: the entire unredeemed epoch entitlement travels with a claim token, or a checkpoint credits former holders before transfer. Do not silently mix these models.

6. Resonate source: https://github.com/Revest-Finance/ResonateContracts . GPL-3.0 public repository, states live at resonate.finance. Current site is reachable as a JS shell but activity/liquidity was not verified; do not label abandoned or currently liquid. The source shows issuer/purchaser queues, fixed rates, lockup periods, separate principal and interest FNFT IDs, and ERC4626 adapters. Very direct prior art for future yield sold upfront.

7. Resonate core: https://github.com/Revest-Finance/ResonateContracts/blob/public/hardhat/contracts/Resonate.sol . `createPool` fixes rate/lockup/packet size; `submitConsumer` issuer and `submitProducer` purchaser sides; principal/interest FNFT creation. The adapter directory contains Aave v2, Yearn, masterchef and JonesDAO integrations: https://github.com/Revest-Finance/ResonateContracts/tree/public/hardhat/contracts/adapters . Existing generalized advance-for-yield mechanisms matter more than marketing differences.

8. Revest: https://docs.revest.finance/ . ERC1155 financial ownership instruments over locked ERC20 assets; ownership trades while asset remains locked. Relevant receipt/rights precedent, not the exact fee source. Documentation labels open beta. No current usage claim.

9. Timeless introduction: https://docs.timelessfi.com/docs/intro/ . Perpetual Yield Tokens receive generated yield; Negative Yield Tokens complement them. ERC20/ERC4626, permissionless immutable EVM protocol per docs. Unlike FeeStrip's intended fixed periods, these rights are perpetual. Uniswap v3 is used as a venue for yield-token trading, not evidence that the yield source itself is native Uniswap fees.

10. Timeless repository: https://github.com/timeless-fi/timeless . AGPL-3.0. Gate abstraction owns vault shares and handles mint, burn and claims; PYT+NYT can recombine to redeem underlying. Yearn and ERC4626 integrations shown. Strong design reference for claim indices and recombination. https://docs.timelessfi.com/docs/smart-contracts/addresses/ documents mainnet deployment files but still lists Rinkeby, a concrete sign that deployment documentation is old. Current active liquidity not verified. Spearbit audit is linked at https://docs.timelessfi.com/docs/smart-contracts/audit/ . Audited original code does not certify adaptations.

11. Revert Lend: https://docs.revert.finance/revert/revert-lend . This is the strongest practical substitute: borrow USDC against Uniswap v3 LP NFTs while positions keep earning and management/auto-range/compound keep operating. Also documents Aerodrome collateral. This directly challenges any claim that fee sales uniquely unlock capital without selling LPs.

12. Revert borrowing and liquidation: https://docs.revert.finance/revert/revert-lend/borrowing and https://docs.revert.finance/revert/revert-lend/liquidations . Loan floats with utilization, no fixed term, collateral value/interest/divergence affect health. FeeStrip's clean difference is no debt to repay or loan-health liquidation, exchanged for selling uncertain fees cheaply and an explicit term/management commitment. Cannot claim universally better capital efficiency: expected fees may be tiny relative to borrowable collateral value.

13. Revert source: https://github.com/revert-finance/lend . Foundry contracts, fork integration tests and existing position tools. Root says License, not a verified permissive SPDX; inspect selected files before borrowing code. Useful source for position valuation, callbacks, automation and state-preserving ownership. Native v3 lending is an actual designed implementation, not an imagined competitor.

14. Uniswap concentrated liquidity: https://developers.uniswap.org/docs/get-started/concepts/liquidity-providers/concentrated-liquidity . Out-of-range positions stop earning fees and become one asset at bounds; re-entry resumes fees. Core reason not to promise pure volume exposure or stable income.

15. Uniswap UNIfication proposal: https://blog.uniswap.org/unification . Official proposal details protocol fee policy and changing LP/protocol split. A claim must reference actual net-of-protocol LP fee growth, never total swap volume multiplied by a permanently assumed tier. This source is a proposal, not proof of the state of every live pool. Read actual chosen pool state at issuance and use realized accumulator at settlement.

Pirex was checked: https://pirex.io/ redirects to https://llama.airforce/pirex . Accessible page is a JS shell and old doc domains did not resolve through the research tool. No detailed current Pirex mechanism/status claim is justified here. Don't use remembered marketing as evidence. Similarly, inaccessible Panoptic URLs do not justify a current deployment claim.

## Product shape that survives

Pitch: 'Sell the next month of your Uniswap fees, without taking a loan.' Need immediately explain 'your position stays committed for the term and can still lose value.' Better buyer pitch: 'Buy this pool range's USDC fee income without owning its ETH/USDC inventory.' Do not shorten to 'buy volume': fees depend on many other factors.

Natural early issuers are LPs with existing long-horizon passive allocation, or treasuries planning to maintain protocol liquidity regardless. Existing externally locked positions cannot automatically be imported; custody must be supported. Wide ranges reduce but do not remove exit probability and may have lower income per capital. Targeting treasury tail-token pools worsens counterparty/adverse selection, so transparent major-asset pools make a cleaner initial market.

Use standardized pool + fee asset + tick range + start/end + strategy + fixed liquidity terms for fungible series. Arbitrary NFT-specific offers are feasible RFQs but fragment secondary liquidity. Units should refer to fixed liquidity or an explicitly normalized backing fraction, not a USD notional whose mark changes. Different ranges are different risks and must not enter one fungible token merely because they are all ETH/USDC.

The protocol can offer arbitrary-position RFQs alongside a small set of standardized series. It should not launch hundreds of empty markets. A simple prepaid spot purchase of a future entitlement avoids the margin engine needed for a leveraged cash-settled fee future. A secondary claim token does not require guaranteed liquidity; buyers must see that distinction.

## Economics and accounting decisions

Illustrative, not projected: seller receives 800 USDC for a term's fees. Realized payout 200 -> buyer loses 600; payout 1,200 -> buyer gains 400, before costs. LP keeps 800 in either case and their residual position, whose value may rise or fall. No buyer gets their 800 principal back separately. Report buyer return as (payout - price - costs) / price; avoid treating the claim like a deposit that also redeems par.

Buyer valuation depends on expected selected-asset fee growth, probability/time in range, competing liquidity/JIT participation, routing/volume, protocol fee changes, term, fee asset denomination, smart-contract risk and resale spread. Past seven-day APR is not a trustworthy price oracle. Public state reduces some asymmetry, but seller knowledge and pending flow make stale fixed quotes vulnerable.

Permissionless donations/wash volume can inflate recent revenue. If someone funds extra fees after buying the claim, they can only recover their share and usually lose net money; but wash trading BEFORE issuance can sell an overstated forecast to naive buyers. A historical accounting proof proves money was paid, not that trading was organic or will recur. Backtest pricing without reward emissions and without assuming quoted secondary liquidity.

Seller-controlled rebalancing after sale creates moral hazard. Buyer cannot buy 'same fee stream' if issuer can remove liquidity or switch to an unproductive range. Immutable fixed range/size is clearest. Precommitted managed strategies are a possible later product, but their swap losses, fees, capital additions and range changes must be accounted for and their manager authority priced. Principal protection cannot be inferred from limiting withdrawals.

If accrued fees remain inside the vault and the claim trades cum-income, price naturally includes accumulated cash plus remaining expected fees. This is simple and composable for AMM/SwapVM settlement. If holders periodically withdraw dividends, transfer hooks/checkpoints must preserve seller accrual and prevent new buyers claiming old income. Explicitly choose one before coding. A mature claim is a claim on final cash, not a token that arbitrarily becomes worthless while holding unclaimed payout.

## Decision gates

Proceed with technical exploration. Do not yet present a market-validated business. Required economic gates: actual LP willingness at a concrete price and management commitment; actual buyer funded quotes; proof that fees support gas/proof/market-maker spreads; out-of-range stress and zero-fee scenarios; compare against Revert loan plus retained management rights. If the only usable sellers accept because quotes overpay based on stale APR, the market is structurally broken even if contracts settle perfectly.
