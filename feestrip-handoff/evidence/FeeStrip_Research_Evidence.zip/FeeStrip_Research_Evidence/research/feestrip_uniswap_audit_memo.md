# FeeStrip: independent Uniswap source feasibility audit

Research cutoff: 11 September 2026. This is source inspection, design inference and executed native-library feasibility testing, not an audit of implemented FeeStrip contracts and not a live-chain integration test.

## Verdict

The narrow product is technically feasible in principle: escrow an existing Uniswap v4 PositionManager NFT, freeze its liquidity/range and all fee-realization operations, sell the USDC leg of native fee entitlement until end-of-block N, collect the native fees later, and allocate the exact historical amount to claims. The NFT can remain invested and be returned unchanged. Historical fee allocation is new FeeStrip work; Uniswap does not expose an automatic maturity-specific collect operation.

Do not say that principal is dollar-protected, withdrawable during the sale term, or unaffected economically. It stays exposed to pool price movement and cannot be rebalanced while locked. Buyers own uncertain future USDC receipts and can lose all their purchase price.

Restrict the first supported collateral class to actual, nonempty, canonical v4 PositionManager NFTs in explicitly allowlisted hookless WETH/USDC pools. Token order is address order and USDC is not universally token0/token1. Hookless matters economically and for security, not merely convenience.

## Exact source snapshots

Both snapshots were resolved through GitHub's commit history AND downloaded through official raw GitHub URLs to `feestrip_uniswap_sources`.

- Core: `46c6834698c48bc4a463a86d8420f4eb1d7f3b75`, 2 April 2026.
  https://github.com/Uniswap/v4-core/commit/46c6834698c48bc4a463a86d8420f4eb1d7f3b75
- Periphery: `dce236d4e2057422d0791d9a973a58765eb46f65`, 20 August 2026.
  https://github.com/Uniswap/v4-periphery/commit/dce236d4e2057422d0791d9a973a58765eb46f65

These are repository heads inspected, not a claim that every deployed contract matches that entire revision. Before deploying FeeStrip, bind chain ID, actual PoolManager and PositionManager addresses, runtime code hash and compiler/storage layout for the selected deployment. The official deployment page explicitly warns that addresses differ between chains.

https://developers.uniswap.org/docs/protocols/v4/deployments

Official docs list Ethereum mainnet PoolManager `0x000000000004444c5dc75cB358380D2e3dE08A90`, PositionManager `0xbd216513d74c8cf14cf4747e6aaa6420ff64ee9e`; Sepolia PoolManager `0xE03A1074c86CFeDd5C142C4F04F1a1536e203543`, PositionManager `0x429ba70129df741B2Ca2a85BC3A2a3328e5c09b4`. Listed-address evidence only: this pass did not read deployed bytecode or exercise those addresses.

## Native ownership and fee accounting

1. PoolManager passes `owner: msg.sender` into the core position lookup. For a PositionManager-created NFT, the core owner remains the PositionManager contract even after the NFT moves to FeeStrip. PositionManager uses `bytes32(tokenId)` as salt. The storage identity is therefore pool ID plus `keccak256(abi.encodePacked(positionManager, int24(tickLower), int24(tickUpper), bytes32(tokenId)))`. Using the depositor or escrow address as core owner is wrong.

2. v4 `Position.State` holds only `uint128 liquidity`, `feeGrowthInside0LastX128`, and `feeGrowthInside1LastX128`. There is no v3-style persistent `tokensOwed0/1` member. Fee growth is realized on liquidity modification and returned as currency deltas.

3. A zero-delta decrease (also a zero-delta increase) realizes BOTH currencies' fees and leaves L unchanged. An empty position cannot be poked. The caller must settle/take the deltas within the unlock; the PositionManager recipe is `DECREASE_LIQUIDITY(tokenId,0,0,0,emptyHookData)` then `TAKE_PAIR(currency0,currency1,escrow)`.

4. PositionManager's external `modifyLiquidities` does not return the `feesAccrued` struct to the calling escrow. Its internal modifier has it. An external adapter should read/check native state and verify actual ERC20 balance changes around its tightly specified action. It must not accept arbitrary action bytes or recipients from an untrusted caller.

Sources:
- https://github.com/Uniswap/v4-core/blob/46c6834698c48bc4a463a86d8420f4eb1d7f3b75/src/PoolManager.sol
- https://github.com/Uniswap/v4-core/blob/46c6834698c48bc4a463a86d8420f4eb1d7f3b75/src/libraries/Position.sol
- https://github.com/Uniswap/v4-periphery/blob/dce236d4e2057422d0791d9a973a58765eb46f65/src/PositionManager.sol
- https://developers.uniswap.org/docs/protocols/v4/guides/position-manager

## Formula and rounding

At successful deposit, take custody first, clear all pre-sale fees to the LP, then read and record L and the fresh USDC fee-growth baseline B. Those steps should be atomic. Start entitlement immediately after that checkpoint transaction state. It is not automatically the start or end of the deposit block.

At the end of block N, let G be global USDC fee growth, O_low and O_high the USDC outside growth at the range boundaries, and t the stored native pool tick. Reproduce StateLibrary's native uint256 modular arithmetic:

- t < lower: I_N = O_low - O_high.
- t >= upper: I_N = O_high - O_low.
- lower <= t < upper: I_N = G - O_low - O_high.

Do not recompute t from sqrtPrice and assume equivalence: Pool.sol documents a boundary state where the stored tick can differ by one after a zeroForOne crossing. Prove/decode the stored signed int24 tick.

Fee liability F_N = floor(L * ((I_N - B) mod 2^256) / 2^128).

At later collection S, with unchanged L and no intervening poke/collection:
F_S = floor(L * ((I_S - B) mod 2^256) / 2^128).

For the constrained funded native-token model, F_S >= F_N. Allocate F_N to fee claims and F_S-F_N to the LP. All WETH fees belong to LP. The residual rounding unit, if present, goes to the LP by this definition. Do not recompute the post-N amount with a second separately rounded multiplication and assume the two legs sum to actual collection.

The core formula intentionally uses unchecked subtraction, and FullMath.mulDiv floors. FullMath and storage parsing must use exact integer arithmetic; JavaScript floating-point or decimal approximations must never settle claims. Detect or explicitly constrain extreme arithmetic/token behavior instead of accepting arbitrary mock/ERC20 supplies.

Source: https://github.com/Uniswap/v4-core/blob/46c6834698c48bc4a463a86d8420f4eb1d7f3b75/src/libraries/StateLibrary.sol

## Historical proof inputs

The current slot layout has the pools mapping at slot 6. Pool base = keccak256(abi.encode(poolId,uint256(6))). Pool.slot0 is at base, global fee growth at base+1/base+2. The ticks mapping is base+4. Tick base = keccak256(abi.encode(int256(tick),base+4)); the fee-growth outside words are tick base+1 and +2. Sign extension for negative tick keys is essential. Positions mapping is base+6.

For a USDC-only claim with immutable L/range and enforced no-touch custody, the essential maturity values are four storage leaves under the same PoolManager account/storage root: slot0, selected global fee-growth word, selected lower outside word, selected upper outside word. Also proving position liquidity and baseline at N is useful defense-in-depth, but it cannot replace the escrow code invariant preventing an intervening collect/re-add cycle. Two endpoints alone cannot prove the absence of arbitrary intervening liquidity changes.

An EIP-1186 response is only witness data. It does not authenticate its own state root. Another component must verify the selected block header against chain-authenticated history and verify all MPT paths. All leaves must be tied to the same N and actual PoolManager address; never trust values from a public API because they look like a proof.

Current state extsload/StateView getters are excellent for live checks and estimates. They do not supply historical state to a contract without the proof adapter.

## Principal can be released while a proof is pending

Proposed robustness improvement (inference, not existing Uniswap behavior): after N, a permissionless capture transaction can collect all actual current fees to isolated escrow, record the USDC amount, and make the unchanged NFT plus WETH fees withdrawable by the LP. Retain ALL captured USDC until the historical liability proof is accepted. The remaining reserve is enough to split F_N from the post-N remainder under the no-touch, hookless assumptions.

This makes proof production independent of principal custody: an archive-provider outage need not trap the NFT after maturity. It still delays fee-claim redemption and the LP's excess USDC. Return/withdraw the NFT with a separate LP-controlled receiver path so a recipient contract rejecting an ERC721 callback cannot block fee capture or settlement. Never release unallocated USDC merely because a timeout elapsed: that could erase the buyers' valid claim.

Capturing the block hash/root within its available history window is still necessary. Returning the NFT does not solve permanent loss of a chain-authenticated maturity root. That liveness issue belongs in the history adapter's design.

## Corrections and hard restrictions

- Native accumulators include donations as well as swap fees. Pool.donate increases the same global fee-growth words. Endpoint storage proofs cannot exclude donations. The legal/economic payoff definition should explicitly include the USDC native fee entitlement, including donations. The app may show swap-derived historic activity separately, but must not promise purely organic trading income. Donations are funded, yet can manipulate displayed volume/yield and selection signals.
- A USDC-only strip pays only USDC-denominated native fees. It is not all of the WETH/USDC pool's fee revenue converted into dollars. Swap direction matters, and no oracle/conversion belongs in the simple settlement path.
- Hook return deltas can change what the caller actually receives despite an apparently valid native `feesAccrued` number. Before-remove hooks also run for a zero-liquidity poke. Arbitrary hooks can revert collection, confiscate a delta, require permission, or change external behavior. Restricting only the hook's current bytecode is insufficient if it delegates to upgradeable behavior. Hookless collateral is the strongest baseline; each supported hook needs a dedicated model later.
- Swaps through the pool continue while the position is locked, but the LP cannot withdraw, increase, decrease, compound, or change its range. This is a meaningful cost to LP supply, especially narrow ranges. A pre-agreed variable-range strategy would be a different contract payoff and require accounting for every change.
- Claims should be fully backed by actual captured fees before redemption. Do not pay users from principal or from another series to make a projected APY true.
- Recent periphery source warns that `_mintFromDeltas` and `_increaseFromDeltas` are deprecated due to missing minimum-liquidity protection under sandwiching. They should not be used in a new-position/migration flow. Existing NFT deposit avoids that minting path entirely.

Sources:
- https://github.com/Uniswap/v4-core/blob/46c6834698c48bc4a463a86d8420f4eb1d7f3b75/src/libraries/Pool.sol
- https://github.com/Uniswap/v4-core/blob/46c6834698c48bc4a463a86d8420f4eb1d7f3b75/src/libraries/Hooks.sol
- https://github.com/Uniswap/v4-core/blob/46c6834698c48bc4a463a86d8420f4eb1d7f3b75/src/interfaces/IPoolManager.sol

## Custody, permits and callbacks

The actual PositionManager is a key security boundary. Its canonical NFT transfer changes the owner and clears the ordinary token approval through its ERC721 implementation; former owner's operator approvals do not authorize actions for the escrow's tokens. Its ERC721 permit checks the CURRENT NFT owner, so the former owner's old signature does not regain permission after deposit. A generic escrow ERC-1271 signature forwarder could accidentally break that protection: do not implement one that validates arbitrary depositor signatures for PositionManager permits.

Current PositionManager transfer automatically unsubscribes an attached subscriber. Unsubscribe invokes external code with a bounded gas budget and catches callback failure. Deposit must be guarded before transferring the NFT, and it must validate state after intake rather than trusting checks before a subscriber callback. PositionManager transfers require PoolManager to be locked (the actual modifier checks `isUnlocked()` and reverts if true); one nearby source comment says the opposite, so the implementation is authoritative.

Escrow should have no generic execution, delegatecall, approval or arbitrary PositionManager forwarding ability. NFT intake should be associated with a pending intended deposit and actual owner, preventing accidental transfers from creating series. One NFT cannot back multiple active series. Freeze/upgrades cannot rewrite existing claim terms; admission governance can stop future risky series without seizing existing ones.

Sources:
- https://github.com/Uniswap/v4-periphery/blob/dce236d4e2057422d0791d9a973a58765eb46f65/src/base/ERC721Permit_v4.sol
- https://github.com/Uniswap/v4-periphery/blob/dce236d4e2057422d0791d9a973a58765eb46f65/src/base/Notifier.sol

## Own-hook alternative

A new hook is a different pool identity: the hook address is part of PoolKey and pool ID. We cannot install a FeeStrip hook onto existing hookless liquidity. Native historical proofs preserve compatibility with that existing inventory.

A purpose-built hook could checkpoint maturity state before the first pool mutation after expiry, so it sees the unchanged end-of-N state even if no transaction occurs exactly at N. However, tracking arbitrary position ranges and many expiries is not automatically O(1). All relevant state-changing paths—including swaps, donations and liquidity modifications—must preserve the boundary, and blindly looping through every expired series on a swap risks making the pool unusable. This is a potential specialized standardized-cohort design, not a drop-in replacement for the proposed wrapper.

Do not attempt to derive arbitrary range fees solely from total afterSwap currency delta: a swap can cross multiple liquidity ranges, and native fee allocation depends on that path. Reusing native fee accounting is safer than reconstructing it from superficial swap output.

## Required proof-of-feasibility tests

1. Existing NFT with old fees: intake, clear old fees to LP, and verify fresh baseline and unchanged L.
2. Mint/collect permission: previous approved operator and old EIP-712 permit cannot alter escrowed NFT.
3. Generate fees while range is below, inside and above price; cross each boundary both ways; verify stored-tick boundary case.
4. At chosen end block N, capture a real storage proof and compare verifier-derived F_N against a native zero-poke executed on a fork of state N.
5. Execute more swaps and donations after N; later collection must allocate exactly F_N to claims and the integer remainder to LP, with identical L and NFT identity.
6. Allow no in-term poke, including zero-delta increase/decrease, and reject arbitrary action forwarding.
7. Bad MPT paths, wrong account, wrong block/root, wrong pool, negative tick encoding, corrupt global/outside words, and replayed settlement fail.
8. Return NFT before proof with all USDC captured; LP may subsequently alter returned position without affecting claims backed by the reserve.
9. Reentrant subscriber/receiver and malicious unsupported token/hook cannot create an admitted series or drain another series.
10. Zero fees, one-unit fees, uneven fractional redemptions, final dust, direct token donations, and duplicate finalization preserve conservation.

Primary conservation invariant after capture: USDC captured for series = unpaid fee-claim liability + paid claims + LP USDC remainder (held or paid), aside from explicitly segregated unrelated direct token donations. Principal quantity means L and range are unchanged; principal token composition and market value are not fixed.

## Licenses

Inspected PoolManager, Pool.sol and Position.sol carry BUSL-1.1. StateLibrary, IPoolManager, PositionManager, ERC721Permit_v4 and Notifier inspected here carry MIT. Integrating deployed contracts and copying/relicensing their source are different activities. Preserve per-file licenses and pin the actual dependency set; do not label all v4 core code unrestricted MIT.

## Executed native Solidity accounting tests

The isolated `feestrip_test` harness compiles actual unmodified pinned core libraries with Solidity 0.8.26 / Cancun and runs with Foundry 1.8.1. `RESULTS.txt` records eight passing tests (zero failures), including two fuzz tests with 512 cases each. Tests cover native checkpoint versus delayed collection, initial old-fee clearing, all three tick branches, exact boundary stored-tick mismatch, donation-only entitlement, a forbidden interim-poke counterexample, fee conservation and rounding residuals.

The reference maturity amount is obtained by executing a native collection on a Foundry state snapshot, then restoring that state to continue trading without the collection. Thus this tests native fee math with actual EVM state transitions, but is not historical proof verification. It does not test ERC20 cash movements, PositionManager NFT custody, claim token redemptions, or actual deployed bytecode. See `feestrip_test/README.md` for exact boundaries and reproducible command.
