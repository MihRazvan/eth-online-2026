# FeeStrip Research Evidence

Evidence date: 2026-09-11. This bundle accompanies FeeStrip Feasibility and Architecture.

This is research and executable feasibility evidence, not production FeeStrip code, an audit, or an integrated onchain deployment. The report distinguishes inspected source, executed primitive tests and remaining integration gates.

## Reproduce

Install Foundry, enter feestrip_test and run `forge test -vv`. Enter feestrip_proof_test and run `forge test -vv --gas-report`. Both configurations select Solidity 0.8.26. The recorded runs used Foundry 1.8.1. Compiler downloads require network access if not already installed. Vendored dependencies preserve original source and per-file licenses. The bundle only normalizes the proof harness compiler path to a portable version selector.

The proof fixture is already included. To regenerate it, install `trie==4.0.0`, `rlp==5.0.0` and `eth-hash[pycryptodome]==0.8.0` in a Python environment, then run `python generate_fixtures.py` inside feestrip_proof_test. This is synthetic Ethereum-style data, not an RPC witness.

## Results

- Native Uniswap libraries: 8 passing tests, two fuzz tests with 512 cases each.
- Polytope synthetic trie verification: 9 passing Solidity tests, one fuzz test with 128 cases, and five Python checks.
- Synthetic proof verification: 1,212,180 measured gas around the external call; 1,834 raw proof-node bytes. No header authentication or complete settlement is included.
- Public RPC attempt: a returned finalized block response was followed by a maximum-proof-window error. A later latest-block attempt received HTTP 403. Returned block data was older than the research date. These observations do not establish contemporaneous chain state or successful mainnet proof integration.

## Source pins

Uniswap v4-core: 46c6834698c48bc4a463a86d8420f4eb1d7f3b75.
Uniswap v4-periphery inspected: dce236d4e2057422d0791d9a973a58765eb46f65.
Polytope solidity-merkle-trees: 6bbc83d5ac33f85761725cf2eba4f8700164e8ba.
SwapVM inspected: afd99c408b4ed610027f4426c6f98650acac9f5f.
Aqua inspected: 9c5c42e5840e8741fba3597c48456c9510212b66.
1inch SDK monorepo inspected: cc4b8c7c646beed8e3dfb2e39597d27f337ea4a7.

The included dependency sources are public upstream code, with their original licenses. No new license is imposed on them. Inspect upstream per-file terms before reuse. Research harness SPDX notices apply to the newly written harness files, not to imported dependencies.

## AI attribution

The research prose, native accounting harness, synthetic fixture generator, proof harness and tests were created with Codex assistance during this investigation. Upstream vendored libraries were obtained from the pinned public repositories. No claim is made that the resulting full protocol has been implemented, deployed or audited. Preserve this distinction and document actual human development contributions in any eventual project submission.

`FILE_SHA256.json` hashes all other bundled files. Logs describe the original execution environment; the portable commands above supersede workspace-specific paths in those logs or nested notes.
