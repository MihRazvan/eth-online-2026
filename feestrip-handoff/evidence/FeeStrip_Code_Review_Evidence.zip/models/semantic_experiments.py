"""Source-informed semantic experiments; not Pendle EVM tests or a FeeStrip implementation."""
from fractions import Fraction
import json

WAD = 10**18
def pendle_interest(principal, previous, current):
    return principal * (current - previous) * WAD // (previous * current)

results = {}
# The transfer hook checkpoints the seller using their pre-transfer balance.
alice_accrued = pendle_interest(100 * WAD, WAD, 11 * WAD // 10)
bob_accrued_at_transfer = 0
assert alice_accrued > 0 and bob_accrued_at_transfer == 0
results["transfer_checkpoint"] = {"seller_owed_SY": str(Fraction(alice_accrued,WAD)), "buyer_owed_past_SY": 0}

# A first-interaction snapshot cannot recover the exact cutoff's index.
at_maturity = pendle_interest(100 * WAD, WAD, 105 * WAD // 100)
first_later_call = pendle_interest(100 * WAD, WAD, 11 * WAD // 10)
assert first_later_call > at_maturity
results["late_snapshot"] = {"exact_cutoff_SY": str(Fraction(at_maturity,WAD)), "first_later_call_SY": str(Fraction(first_later_call,WAD))}

# Clamping an exchange rate does not turn LP principal into a fixed USDC claim.
previous = 12 * WAD // 10
current_rate = 9 * WAD // 10
clamped = max(previous,current_rate)
assert pendle_interest(100*WAD,previous,clamped) == 0
results["declining_rate"] = {"clamped_index": str(Fraction(clamped,WAD)), "new_interest_SY": 0}

# FeeStrip proposal: hold one finalized USDC pool, burn shares for a fraction of
# remaining pool. This is deliberately not Pendle's per-owner accrual accounting.
def redeem(pool, supply, shares):
    amount = shares * pool // supply
    return pool-amount, supply-shares, amount
pool, supply = 1_000_001, 100
payouts = []
for shares in [33,33,34]:
    pool,supply,paid = redeem(pool,supply,shares)
    payouts.append(paid)
assert pool == supply == 0 and sum(payouts) == 1_000_001
results["finalized_pool_conservation"] = {"payouts_micro_USDC": payouts, "remaining_pool": pool, "remaining_supply": supply}

# A reward token balance is not necessarily all the series' income.
period_USDC, later_LP_USDC, donation_USDC = 70, 25, 5
wallet_balance = period_USDC + later_LP_USDC + donation_USDC
assert wallet_balance != period_USDC
results["reserve_separation"] = {"wallet_balance": wallet_balance, "buyer_period_claim": period_USDC, "other_obligations_and_donation": later_LP_USDC+donation_USDC}

print(json.dumps({"experiment_count":len(results),"passed_assertions":True,"scope":"Python semantic models only; no Pendle suite or EVM execution", "results":results},indent=2))

