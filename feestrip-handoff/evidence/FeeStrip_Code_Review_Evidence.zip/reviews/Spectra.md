# Spectra source review for FeeStrip

Reviewed 2026-09-11. This is a source/code reuse pass, not a security audit. Downloaded immutable GitHub snapshots and read code, relevant tests, license notices, documentation, and the bundled Certora report. No Spectra Solidity tests were executed, no production bytecode was matched, and no claim about live deployment equivalence follows from this review. Pin metadata, archive hashes, and key-file hashes are in `spectra-pins.json`.

## Recommendation

Borrow Spectra's separation of capital ownership from yield rights, explicit maturity states, lifecycle previews, guarded execution, and test scenarios. Do not fork its PT/YT accounting into FeeStrip. Spectra's yield token represents future accrual to a holder plus separately recorded earned yield; FeeStrip's token must carry all unredeemed rights from the entire escrow period. Spectra also freezes a live rate when someone first calls after maturity, whereas FeeStrip requires a historical block-N cutoff. These are material economic differences, not naming differences.

For the hackathon product, build a small NFT escrow, a conventional fixed-supply ERC20 claim, a proof/settlement module, a narrow convenience router, and a reader. Use the actual 1inch Aqua/SwapVM integration for trading rather than importing Spectra's Curve pricing or its general-purpose upgradeable diamond.

## Provenance and versions

The official [Spectra user documentation audit page](https://docs.spectra.finance/security/audits) links `perspectivefi/spectra-core`; [developer documentation](https://dev.spectra.finance/docs/guides/tokenizing-yield) describes the ERC4626-backed PT/YT protocol. The same [Perspective GitHub organization](https://github.com/perspectivefi) lists the newer public core and diamond releases. This establishes official-source provenance, not deployment equivalence.

| Repository | Immutable public revision | Date | Scope of reviewed snapshot |
|---|---|---|---|
| `perspectivefi/core-v2-public` | [`1b7069130a1353b8eeea5360b5effd43bfbf54cf`](https://github.com/perspectivefi/core-v2-public/commit/1b7069130a1353b8eeea5360b5effd43bfbf54cf) | 2026-08-26 | Sanitized core release; README names private origin `401bcc6847d9290b4f679caaa1413ff56219e16c`; excludes private history, deployed addresses, generated outputs, and core tests. |
| `perspectivefi/diamond-router-public` | [`221441b506fe82f14671c213f9ad1031676c0af1`](https://github.com/perspectivefi/diamond-router-public/commit/221441b506fe82f14671c213f9ad1031676c0af1) | 2026-08-26 | Selector/command routing infrastructure, access control, tests, and May 2026 bridge audit. Does not include a full Spectra trading command suite. |
| `perspectivefi/spectra-core` | [`2fa3cbf393acb7b25e20a2aef47aaf7e5681fdb2`](https://github.com/perspectivefi/spectra-core/commit/2fa3cbf393acb7b25e20a2aef47aaf7e5681fdb2) | 2025-04-25 | Older complete EVM core, monolithic command router/utilities, public tests. Use this expressly as an older source. |
| `perspectivefi/spectra-subgraph` | [`bfeeb5a0dbdeb16011f0729e6ae4fc125dade8a1`](https://github.com/perspectivefi/spectra-subgraph/commit/bfeeb5a0dbdeb16011f0729e6ae4fc125dade8a1) | 2026-08-15 | MIT indexer; its ABI/mappings are not automatically aligned with the later August public core release. |

Current [deployed-address documentation](https://dev.spectra.finance/docs/technical-reference/deployed-contracts) lists routers and utilities by chain. I did not verify those contracts' runtime code against these public commits. Documentation still describes the monolithic router command interface; neither an organization repository timestamp nor an official address listing proves a specific implementation version.

## Actual current core behavior

The relevant implementation is [PrincipalToken.sol](https://github.com/perspectivefi/core-v2-public/blob/1b7069130a1353b8eeea5360b5effd43bfbf54cf/src/tokens/PrincipalToken.sol), with [YieldToken.sol](https://github.com/perspectivefi/core-v2-public/blob/1b7069130a1353b8eeea5360b5effd43bfbf54cf/src/tokens/YieldToken.sol) and [PrincipalTokenUtil.sol](https://github.com/perspectivefi/core-v2-public/blob/1b7069130a1353b8eeea5360b5effd43bfbf54cf/src/libraries/PrincipalTokenUtil.sol).

### Mint and redeem

`deposit` pulls underlying, deposits to an ERC4626 IBT, and passes returned IBT shares to `_depositIBT`. `depositIBT` pulls a specified IBT amount directly. `_depositIBT` checkpoints the YT receiver, computes tokenization fees, mints equal PT and YT quantities to separately selectable recipients, and rejects zero minted shares. The public overloads expose `minShares`.

Before expiry, `_beforeRedeem` requires matched PT/YT balances, checkpoints the owner, and burns both. After expiry, it burns PT alone and ensures expiry rates are stored. Delegated redemption spends PT allowance and, pre-expiry, YT allowance. `redeemForIBT` pays in IBT shares; `redeem` additionally redeems the IBT vault. Withdraw burns round upward, while redeem outputs round downward. The same file has min-output/max-input overloads.

**FeeStrip lesson:** enforce backing and issuance in one atomic operation; separate LP/NFT recipient, claim recipient, payer, and refund recipient explicitly; expose slippage and deadline bounds where assets are swapped or external vaults are involved. FeeStrip has an NFT capital right, not a fungible ERC4626 PT, and requires no initial deposit of interchangeable principal assets.

### Transfer and earned yield: the critical incompatibility

`YieldToken.transfer` and `transferFrom` invoke `PrincipalToken.beforeYtTransfer`, which calls `updateYield` for both sender and receiver before balances change. `updateYield` records each account's last PT/IBT rates and its separately accrued `yieldOfUserInIBT`. `PrincipalTokenUtil.computeYield` uses the account's actual YT balance and rate history. Transfer changes future yield ownership, while already earned yield remains with the account that held the YT during accrual. `claimYield` clears that account credit before paying it.

FeeStrip's specified token has the opposite transfer semantics: someone buying the claim receives the remaining claim on the entire sold period, including income accrued before purchase. Do not import the Spectra YT hook, per-address rate checkpoints, or account yield credit. A conventional ERC20 balance is sufficient while issuance stays fixed and settlement allocates the period reserve pro rata. Burn redeemed claim units and keep reserve/supply accounting explicit; no accrual checkpoint on ERC20 transfer is needed for this economic model.

The old public [`testTransferYTAndPT`](https://github.com/perspectivefi/spectra-core/blob/2fa3cbf393acb7b25e20a2aef47aaf7e5681fdb2/test/PrincipalToken/PrincipalToken.t.sol#L2736) asserts that both users' previously earned yield remains unchanged immediately after a YT transfer. This is valuable as a precise contrast: FeeStrip should instead test that the buyer receives the transferred share of all unredeemed period rights.

### Maturity is not a historical snapshot

`storeRatesAtExpiry` is public, allowed at/after timestamp expiry, and callable only once. It reads `_getCurrentPTandIBTRates`, which calls the underlying IBT's live `previewRedeem`. `_updatePTandIBTRates`, redemption, and withdrawal automatically trigger storage if the first post-expiry interaction finds no snapshot. Until that call, getters can still read current rates. Once stored, `_getPTandIBTRates` returns the frozen values.

Thus a delayed first interaction can include rate movement after nominal maturity. Spectra has no historical block header/storage proof in these paths. Its one-time flag is a reusable state-machine pattern; the value being frozen is unsuitable for FeeStrip's exact block N settlement. For FeeStrip, store and validate the proven N state, not the state at NFT return/fee collection block C. Collecting at C and returning the NFT before proof can still be sound if all collected funds stay reserved until the proven N allocation is finalized.

`YieldToken.balanceOf` and `totalSupply` return zero after timestamp expiry; `actualBalanceOf` retains balances for yield computation. Nonzero transfers and public burns revert after expiry. Do not copy this: FeeStrip's matured, unresolved or unredeemed claims still have value and should remain visible. Keep normal balances and an explicit series status such as active / returned-awaiting-proof / redeemable / redeemed.

### Rate loss, donations, and reserves

Spectra's `_getCurrentPTandIBTRates` lowers PT value when the IBT rate falls. `computeYield` compensates for path-dependent losses and recoveries, including rounding and a small-value safety threshold. This machinery is specific to ERC4626 exchange-rate yield. FeeStrip is measuring two independent token fee-growth accumulators on a frozen Uniswap position; do not import PT depeg math, RAY-rate assumptions, or the `SAFETY_BOUND = 100` policy.

A direct IBT donation to the PT increases reported `totalAssets()` and flash-loan capacity but does not directly change mint/redemption rate formulas: those use IBT conversion rates and PT rates, not PT total assets divided by PT supply. A donation to the underlying IBT vault may change that vault's exchange rate, which Spectra does recognize. These are different donation surfaces. I found no explicit donation/inflation test named as such in the older reviewed Solidity tree; this is a search result, not proof no test scenario covers donations.

For FeeStrip, authenticate settlement amounts from position accounting and custody balance deltas. Never treat every token already in escrow as earned fees, never sweep another series' reserve, and do not let unsolicited transfers alter initial claim supply or the block-N fee measurement. Distinguish a direct ERC20 donation to escrow from Uniswap pool donations that enter the pool's actual fee-growth accounting; whether the latter count must follow the product's fee definition.

Spectra supports flash loans of its entire IBT balance and externally supplied rewards logic through restricted delegatecall. Neither feature belongs in FeeStrip's minimum escrow. Avoid lending the reserved fee currencies or allowing arbitrary delegation from the NFT custodian.

## Routers, previews, and rollover

The older [Router.sol](https://github.com/perspectivefi/spectra-core/blob/2fa3cbf393acb7b25e20a2aef47aaf7e5681fdb2/src/router/Router.sol) exposes batched `execute`, optional deadline, `previewRate`, and `previewSpotRate`; [Dispatcher.sol](https://github.com/perspectivefi/spectra-core/blob/2fa3cbf393acb7b25e20a2aef47aaf7e5681fdb2/src/router/Dispatcher.sol) implements the command operations and separate preview paths. The original caller is cached across router self-calls; third-party reentry is rejected; flash callbacks require the recorded lender. This is useful context for Aqua/SwapVM callback and payer handling, but does not establish that Spectra's callback model works unchanged for those systems.

`previewRate` includes the modeled pool price impact and fees, while `previewSpotRate` ignores trade size. Public [routing docs](https://dev.spectra.finance/docs/guides/routing) explicitly note that some commands cannot be previewed. Do not present a preview as a settlement guarantee. FeeStrip should separately expose read-only custody/series state, estimated current fees, proven terminal entitlement when available, and actual transaction simulation/min-output execution bounds. An unproven fee estimate must not look redeemable.

I found no dedicated rollover function or command in the reviewed older router/current core/current diamond Solidity trees. Redemption and new deposit can be composed using older commands, but this is not evidence of a tested, public FeeStrip-like rollover implementation. A new FeeStrip period must receive a new series identity and baseline. Reusing the same NFT after return should not merge the earlier period's reserve or unresolved proof rights into the next period.

The current [CommandsModule.sol](https://github.com/perspectivefi/diamond-router-public/blob/221441b506fe82f14671c213f9ad1031676c0af1/src/modules/CommandsModule.sol) dispatches registered command selectors by delegatecall, checks input-length equality, bubbles failures, optionally returns results, preserves the top-level caller/value, and restricts command-management updates. [DiamondRouter.sol](https://github.com/perspectivefi/diamond-router-public/blob/221441b506fe82f14671c213f9ad1031676c0af1/src/DiamondRouter.sol) delegates registered function selectors and pauses fallback routing. [LibExecutionModule.sol](https://github.com/perspectivefi/diamond-router-public/blob/221441b506fe82f14671c213f9ad1031676c0af1/src/modules/libraries/LibExecutionModule.sol) owns the namespaced execution state.

The diamond README mentions `executeView`, but there is no `executeView` implementation in the reviewed `src` tree. Its README examples are not an authoritative ABI. The public release provides infrastructure and mock test modules, not a ready-made yield marketplace. FeeStrip benefits from typed, narrow entrypoints; importing diamond upgrades, arbitrary commands and multiple proxy layers increases review work without solving its historical settlement problem.

## Tests and audit evidence

These tests were read, not executed. Current core's README explicitly excludes its test suite. Older tests remain useful because a token-level comparison after stripping comments/formatting found no behavioral change in the reviewed YT transfer/maturity logic or `PrincipalTokenUtil` yield calculations; dependency versions differ, so this is not proof of runtime equivalence.

| Source | Relevant test material | Adapt to FeeStrip |
|---|---|---|
| [Older PrincipalToken tests](https://github.com/perspectivefi/spectra-core/blob/2fa3cbf393acb7b25e20a2aef47aaf7e5681fdb2/test/PrincipalToken/PrincipalToken.t.sol) | `testTransferYTAndPT`, `testYTTransferFails`, `testYTBalanceOfAndTotalSupplyWhenExpired`, delegated redeem tests, wrong-caller tests, slippage and pause tests | Same actor permutations and boundary cases; reverse the transfer-yield expectations and preserve matured balances. |
| [Older CustomDecimals tests](https://github.com/perspectivefi/spectra-core/blob/2fa3cbf393acb7b25e20a2aef47aaf7e5681fdb2/test/CustomDecimals.t.sol) | `testRatesAfterExpiryFuzz`, `testPTYieldConsistencyFuzz`, deposit/redeem and preview fuzz tests | Different token decimals, tiny payouts, zero fee intervals, claim splitting, delayed settlement, fixed N versus changing C. |
| [Older ERC5095 property checker](https://github.com/perspectivefi/spectra-core/blob/2fa3cbf393acb7b25e20a2aef47aaf7e5681fdb2/test/ERC5095/PTPropertyCheck.t.sol) | Generic asset/share properties and setup using RPC environment | Use invariant-oriented assertions; do not claim FeeStrip implements ERC5095 or require an archive RPC for every local unit test. |
| [Current ExecutionModule tests](https://github.com/perspectivefi/diamond-router-public/blob/221441b506fe82f14671c213f9ad1031676c0af1/test/ExecutionModuleTest.t.sol) | `testExecuteWithExpiredDeadline`, `testMultipleCommandsExecution`, return-data tests, allowance tests | Atomic creation/listing/redemption flows, deadlines and rollback. Its mock permit simply approves; it does not validate signature security. |

The [2024 Code4rena report](https://code4rena.com/reports/2024-02-spectra) concerns an older competition snapshot. M-01 covered ERC5095 allowance/max-function incompatibilities; current source visibly spends owner allowance and returns zero maxima when paused. M-02 describes an IBT vault price-reset/deflation interaction with PT flash lending. The sponsor's response acknowledges dependence on the vault's own resistance to price resets; do not summarize this as a universally fixed risk merely because the high-level docs say all issues were addressed. FeeStrip should borrow the lesson that a locally correct accounting wrapper still inherits critical assumptions from its asset/protocol adapter.

The bundled [May 2026 Certora report](https://github.com/perspectivefi/diamond-router-public/blob/221441b506fe82f14671c213f9ad1031676c0af1/audits/2026-05-Certora-Spectra-Bridge.pdf) reviewed a bridge monorepo from `fed17f1` initially to `729e914` finally and a separate configuration revision `01ea96d`. Its [scope README](https://github.com/perspectivefi/diamond-router-public/blob/221441b506fe82f14671c213f9ad1031676c0af1/audits/README.md) identifies nine diamond source files and asserts byte-for-byte equality to the final reviewed diamond sources. I did not independently compare the unavailable monorepo revision. The full engagement reports 4 medium, 6 low, 3 informational findings, no critical/high; only L-02 is attributed to the diamond framework.

L-02 concerned cached native transaction value across multiple commands and nested flash loans, marked fixed by Certora in `d0c8f36` and `aad97ef`. The current command module visibly preserves cached value on nested self-execution; the public framework does not include the bridge/Kyber command implementations needed to independently validate all remaining-value handling. FeeStrip's router should use an explicit remaining native-value budget and refund recipient, and test multiple native-currency actions plus nested callbacks. Do not call the whole current core or FeeStrip audited based on this report.

## Version and indexer traps

The current core differs from the older source in naming, dependency/import setup, compiler range, and fee collection: old `claimFees(uint256 minAssets)` redeemed IBT into underlying and used a three-field `FeeClaimed`; current `claimFees()` transfers IBT and emits two fields. This matters to integrations even though the principal/yield calculation itself is substantially unchanged in the compared files.

The August subgraph's [`abis/PrincipalToken.json`](https://github.com/perspectivefi/spectra-subgraph/blob/bfeeb5a0dbdeb16011f0729e6ae4fc125dade8a1/abis/PrincipalToken.json) still declares `FeeClaimed(user,redeemedIbts,receivedAssets)` and [`src/mappings/futures.ts`](https://github.com/perspectivefi/spectra-subgraph/blob/bfeeb5a0dbdeb16011f0729e6ae4fc125dade8a1/src/mappings/futures.ts) reads `receivedAssets`. It cannot be assumed to ingest the newer two-field event merely because the repo description says core-v2.

Useful MIT patterns include dynamic series/token data sources in `handlePTDeployed`, event identities combining transaction hash and log index, account/asset relations, and transaction history. Adapt event schemas and chain-aware IDs to FeeStrip's factory; do not copy YT-zeroing or account yield-calculation behavior. The subgraph's [`Yield.updateYieldForAll`](https://github.com/perspectivefi/spectra-subgraph/blob/bfeeb5a0dbdeb16011f0729e6ae4fc125dade8a1/src/entities/Yield.ts) loops over yield-generating accounts and queries contract views; FeeStrip does not need that model for a fixed period claim, and the indexer must never become the source of proof/settlement authority.

## Reuse and licensing decision

| Candidate | Decision | Reason |
|---|---|---|
| Standard ERC20/permit, SafeERC20 and mulDiv building blocks | Reuse directly from their canonical OpenZeppelin release, with pin and notices | Spectra uses them, but importing these canonical dependencies avoids copying unrelated PT/YT economics. Pick a stable supported version, not automatically Spectra's `5.4.0-rc.1`. |
| MIT subgraph helpers and event/entity structure | Direct adaptation is available subject to MIT notice retention | Useful UI history scaffolding; rewrite event ABI/status/accounting semantics for FeeStrip. |
| PT/YT mint-to-separate-recipients and explicit previews | Pattern only | Good transaction/API design; underlying capital model and claim economics differ. |
| One-time expiry flag and explicit events | Pattern only | Preserve finalization uniqueness while authenticating historical N values. |
| YieldToken and per-user earned-yield checkpoints | Avoid | Violates all-unredeemed-period-rights transfer semantics; matured balances disappear. |
| PT exchange-rate/depeg calculations | Avoid | Wrong quantity and risk model for two-currency v4 fee growth. |
| Diamond command framework | Avoid for minimum product | Much wider custody/upgrade/dispatch surface, restrictive current license, no historical-proof benefit. |
| Flash loans, rewards delegatecall, Curve trading/oracle machinery | Avoid | Out of FeeStrip's defined custody and marketplace requirements. |
| Audit and test scenarios | Reimplement relevant assertions as FeeStrip tests | Evidence informs threat model; it does not transfer assurance. |

License specifics must not be collapsed into one BUSL label:

- [Current core LICENSE](https://github.com/perspectivefi/core-v2-public/blob/1b7069130a1353b8eeea5360b5effd43bfbf54cf/LICENSE) and [older core LICENSE](https://github.com/perspectivefi/spectra-core/blob/2fa3cbf393acb7b25e20a2aef47aaf7e5681fdb2/LICENSE) say BUSL-1.1, but specify a Change Date that is the earlier of 2023-07-01 or an ENS-specified date and a GPLv2-or-later Change License. The literal dated trigger is in the past. The new public README still labels its release BUSL. Therefore do not confidently characterize core as a fresh four-year production ban, or as permissively licensed. Code-copy decisions need to account for the GPL transition language and notices.
- [Diamond LICENSE](https://github.com/perspectivefi/diamond-router-public/blob/221441b506fe82f14671c213f9ad1031676c0af1/LICENSE) instead grants no additional production use and sets change at the fourth anniversary of first public distribution. For the observed August 2026 release, assume production copying needs an appropriate grant until the applicable change date is established; this is distinct from the core notice.
- [Diamond third-party notices](https://github.com/perspectivefi/diamond-router-public/blob/221441b506fe82f14671c213f9ad1031676c0af1/THIRD_PARTY_NOTICES.md) identify specific MIT exceptions, including proxy adaptations and selected diamond libraries. Those exceptions do not make the command module or whole router MIT.
- [Subgraph LICENSE](https://github.com/perspectivefi/spectra-subgraph/blob/bfeeb5a0dbdeb16011f0729e6ae4fc125dade8a1/LICENSE) is MIT. This is the clearest direct-copy source among these four repositories.

## FeeStrip acceptance cases motivated by this review

1. Alice receives a fixed claim supply, sells half after fees accrue, and Bob receives half of the eventual unredeemed period entitlement; Alice cannot retain separately checkpointed income for the sold units.
2. A matured claim remains visible, transferable if the product permits, and redeemable once proof finalizes; maturity alone does not zero the ERC20 balance.
3. Collection block C can move arbitrarily later while the proven block-N buyer allocation stays identical. Late fees belong to the LP and remain reserved until determinable.
4. Return the NFT, then perform unrelated NFT operations and even create a new period: these cannot alter the old frozen position metadata, old reserve, or N-proof inputs.
5. Wrong-pool/chain/token/range/N proofs fail; proof replay cannot settle twice; reentry cannot return twice, reserve twice, or redeem twice.
6. Direct token donations do not dilute claims, create earnings, or permit withdrawal of another series' reserve. Native currency, unusual decimals and tiny split claims obey the same conservation invariant.
7. Router quotes disclose unresolved proof status; execution bounds and full rollback protect an atomic create-and-list or buy-and-redeem flow; no router command can spend escrow reserves through generic allowances.
8. Indexers reconstruct lifecycle transitions using the actual deployed ABI, transaction hash and log index; user-facing balances and payouts can be checked against on-chain views without trusting the indexer.
