# Pendle source review for FeeStrip

Review date: 2026-09-11. This is a targeted design and code-reuse review, not a security audit. Scope is public source pinned below, plus one downloaded audit report. FeeStrip here sells **only the native USDC fee leg** of an escrowed canonical hookless Uniswap v4 NFT. There is no conversion into USDC and no price oracle. The other token's fees remain the LP's property unless a separate series is explicitly created.

## Findings that change the design

1. **Pendle already has a close concentrated-liquidity NFT precedent.** Its Kyber Elastic SY accepts NFTs for a fixed pool/range, mints fungible SY shares, claims position fees as rewards, and can feed Pendle's PT/YT machinery. FeeStrip cannot credibly distinguish itself merely as “Pendle for LP fees.”
2. **Pendle's YT transfer semantics are the opposite of the proposed cum-income strip.** Pendle checkpoints each owner's accrued yield before moving balances. The seller keeps past unpaid yield. FeeStrip's historical unpaid period income should travel with the tokens, so copying InterestManagerYT would implement the wrong asset.
3. **Pendle does not provide an exact historical expiry-block proof.** Its first post-expiry action snapshots then-current indices. FeeStrip needs a separately designed proof boundary for end-of-block N.
4. **The useful borrow is modular architecture and invariant discipline.** A collateral adapter, immutable series identity, reserve ownership, clear mint/burn authorization, execution checks after callbacks, and precise rounding transfer well. The PT/SY AMM curve, exchange-rate interest model, pooled-NFT management, and owner accrual ledgers do not.
5. **The current public repos are not a public regression suite.** Complete trees contain no conventional test paths/files. Audit PDFs concern specified older code scopes; they do not certify a FeeStrip derivative or all current adapters.

## Source pins and evidence

| Repository | Retrieved default-branch commit | Commit date / title |
|---|---|---|
| pendle-finance/pendle-core-v2-public | f24265966bb53f75d834ad705decde8e479d3a33 | 2026-09-04, v6.10.0 (#863) |
| pendle-finance/Pendle-SY-Public | 73676d931102a369a978a713abfd0b48e3e34361 | 2026-02-07, Add Merkl claim to PendleERC20WithOracleSY (#287) |

The pins came from GitHub's latest default-branch commit API, not a release-name assumption. Recursive trees were complete (`truncated=false`): 385 core blobs and 1,038 SY blobs. Twenty-nine text files were retrieved at these exact commits, saved locally, and every copy was verified against its Git blob SHA. `source_files.json` records path, URL, SPDX label, Git blob and SHA-256 for each. `source_pins.json` records repository pins. The source selection is deliberate, not an exhaustive review of every source file or dependency.

## Minting and principal ownership

[PendleYieldToken.sol][yt] `mintPY`, `_mintPY` and `_calcPYToMint` consume floating SY, convert its amount into asset units at the current PY index, then mint equal PT and YT quantities. `_getFloatingSyAmount` is current SY balance minus `syReserve`; the SY transfer and mint call must be one atomic operation if the depositor expects to own the receipt. The router's [ActionBase.sol][action] `_mintPyFromSy` illustrates that composition and adds a minimum output check.

Before expiry, `redeemPY` burns both PT and YT; the single-recipient helper uses the minimum of the tokens' balances held by the YT contract. After expiry, it burns only PT. `_calcSyRedeemableFromPY` divides principal units by the current index and separately identifies post-expiry SY interest. [PendlePrincipalToken.sol][pt] allows only its linked YT to mint or burn PT; the factory alone initializes that link.

**Borrow:** restrict issuance and burns to the series controller; keep custody/backing accounting separate from the ERC20; ensure creation and collateral intake are atomic; expose exact collateral and series identity; make rounding and minimums explicit.

**Do not copy:** FeeStrip does not need equal fungible principal tokens when the original NFT is returned to its recorded owner. The NFT capital has changing token composition and market value. A 1:1 PT in asset units, or a max-clamped exchange rate, does not describe this principal. FeeStrip's initial fixed supply is a fraction of a specified NFT's entire fee period, not an amount of SY principal. Do not permit late minting into that same full-period claim: it dilutes earned income unless the depositor compensates existing holders under a separately specified model.

The factory's [`createYieldContract`][factory] is permissionless for an SY and valid expiry; uniqueness is keyed by SY and expiry. It does not establish the economic safety of an arbitrary SY. Adapt the identity pattern to chain, canonical position-manager address, NFT ID, canonical pool key, ticks, liquidity, USDC side, baseline, end block and settlement rules. If all positions are per-NFT isolated, NFT ID belongs in identity. An address labeled “SY” is not itself collateral validation.

## Transfer checkpointing: the decisive mismatch

[PendleERC20.sol][erc20] calls `_beforeTokenTransfer` before changing balances. YT's hook calls `_updateAndDistributeRewardsForTwo(from,to)` and then `_distributeInterestForTwo(from,to)`. [InterestManagerYT.sol][interest] writes each owner's `index` and `accrued` fields. That accrued balance is not transferred with the ERC20. A later `redeemDueInterestAndRewards(user,...)` pays that user even after they sold the YT.

Interest for principal balance P over PY indices i0 and i1 is economically P × (1/i0 − 1/i1), paid in SY. The source uses fixed-point floor division. Thus a user holding 100 YT through index 1.00 to 1.10 is owed about 9.090909 SY; after transferring all YT, that past interest is still owed to the seller. The buyer starts at 1.10 with no claim to that historical amount.

[RewardManagerAbstract.sol][rewardabstract] applies the same owner-checkpoint idea to reward tokens. YT reward shares include both the SY represented by YT and the owner's already accrued SY interest. Therefore reward updates must happen **before** interest payout changes those reward shares. The source explicitly documents this ordering requirement.

**FeeStrip change:** use a normal balance-only ERC20 for a one-shot settlement pool. Before settlement, tokens carry their proportional entitlement to the whole series' unredeemed USDC income. After proof/finalization, burning q shares against remaining supply S releases `floor(q × remainingUSDC / S)`. The final holder receives the residual; fractional rounding can shift tiny amounts with claim partition/order, so bound and document that. Do not calculate every later payout as `remainingReserve × q / initialSupply`, which underpays later holders. Alternatively, use a fixed finalized payout ratio with an explicit dust policy.

For the initial design, prohibit partial income redemption before the whole period is finalized. Allowing someone to harvest without burning while leaving identical nominal tokens circulating complicates what “all unredeemed accrual travels” means. A one-shot pool avoids that ambiguity and makes Aqua/SwapVM balance-based inventory integration simpler. Preserve ordinary transfers while proof is pending if that is the chosen market behavior; transferred tokens still carry the period claim.

A custom PendleERC20 fork is not necessary: besides the accrual hooks, it makes transfers nonReentrant and rejects self-transfers. Those choices suit its external-calling hooks but would add unusual behavior to FeeStrip's simpler token. Use a well-supported ERC20 implementation compatible with the selected compiler/dependencies.

## Expiry, delayed settlement and reserve ownership

[MiniHelpers.sol][mini] defines expiration by `expiry <= block.timestamp`. In YT, `_setPostExpiryData` is idempotent and saves the first PY index and reward indices observed by a post-expiry state-changing path. It redeems external rewards and records the current balances owed to users. `_getInterestIndex` subsequently uses that saved first index. It does not accept a header, storage proof, block number, or historical index witness.

This means delayed first interaction can include yield earned after the nominal timestamp up to the first observed snapshot. Its source calls this the first/earliest post-expiry index. That is materially different from proving exactly the state at the end of N. In the simple model, 100 principal units with an exact-cutoff index 1.05 have about 4.761904 SY interest; a first snapshot at 1.10 instead gives about 9.090909 SY. This is a difference of product semantics, not a newly alleged exploit in Pendle.

**Borrow:** explicit maturity state, idempotent finalization, and separate reserves for categories of beneficiaries.

**FeeStrip change:** use `matured`, `collected/NFT-returned`, `proved` and `finalized` as distinct state facts. A maturity condition is not a proof and proof submission is not collection. After N, collect all current fees before returning the NFT, hold the captured native USDC in the settlement reserve, then prove the USDC amount attributable to the defined window and split the captured reserve between buyers and the LP's later USDC fees. The non-USDC leg can be returned to the LP immediately under the stated product. Return of the NFT before historical proof requires the reserve already be secured atomically; a later attempt to collect after handing the NFT back is not equivalent.

Do not import Pendle's treasury allocation: Pendle sends post-expiry yield to its treasury, while FeeStrip owes later fees to the LP. Nor should arbitrary third-party deposits or market inventory be counted as fee income.

The separate [SY RewardManager.sol][rewardmanager] assumes the entire balance of a reward token is the contract's reward inventory; `_updateRewardIndex` uses current balance minus its saved balance. [SYBaseWithRewards.sol][syrewards] expressly warns that `yieldToken` must never also be a reward token. These are concrete warnings against reusing a generic balance-delta reward distributor inside a wallet also holding other USDC obligations. FeeStrip must track which USDC is series reserve, later LP property, market inventory, or an unsolicited donation. Keep the reserve outside Aqua's spendable shared maker inventory.

## SY adapters, including real AMM/NFT precedents

[SYBase.sol][sybase] provides deposit/redeem, token allowlists, previews, minimum-output checks, and an exchange-rate interface. This is a useful adapter boundary. It is not a generic proof that every LP position has a stable principal denomination.

| Actual implementation | Source behavior | FeeStrip lesson |
|---|---|---|
| [PendleERC4626SY.sol][erc4626] | Wraps vault shares or deposits assets into ERC4626; exchange rate is totalAssets/totalSupply; underlying metadata supplies asset decimals | Separate wrapper shares, economic asset and token decimals. This is a vault exchange-rate model, not NFT fee accounting. |
| [PendleAuraBalancerStableLPSYV2.sol][balancer] | Wraps BPT or joins Balancer, stakes through Aura; unwraps/withdraws; exchangeRate calls BPT rate provider; handles farming rewards | LP integrations already exist. Rate reads themselves can need protocol-specific reentrancy protection. |
| [PendleCurvePool2TokenSYUpg.sol][curve] | Accepts constituent tokens, LP or gauge; deposits/withdraws; uses Curve virtual price; claims CRV | “Liquidity asset” is distinct from USD price. The file warns of virtual-price read-only reentrancy. |
| [PendleAerodromeVolatileSY.sol][aero] | Holds staked volatile LP; zaps constituent tokens; constant exchangeRate=1; streams the gauge reward token | A reward-only strip can use a constant principal-unit index, but market volatility in LP principal still exists. This particular file claims gauge rewards, not a generic proof that all swap fees are stripped. |
| [PendleKyberElasticSYUpg.sol][kybersy] plus [KyberNftManagerBaseUpg.sol][kyberbase] | Accepts NFTs, creates fungible shares; validates canonical pool/range; manages one merged position; fee-growth sync and reinvestment-token burns produce rewards | The closest precedent: concentrated-liquidity NFT fees plus fungible yield abstraction are already represented in Pendle source. |

The Kyber implementation is especially useful to read:

- `_validateTokenIdAndGetLiquidity` reads the official position manager and verifies factory-derived pool identity and exact immutable ticks.
- `_depositNft` takes custody. The initial NFT retains a minimum liquidity reserve to keep ticks initialized; later NFTs go through `_mergeNft`.
- `_mergeNft` removes incoming liquidity, collects floating tokens, returns the incoming position's previously owed reinvestment rewards to its depositor, burns the incoming NFT, and adds its liquidity to the managed position.
- That explicit old-reward treatment is visible in the merge path; it is not proof that every first-deposit path has FeeStrip's required fee-clearing baseline. Implement and verify FeeStrip's admission clearing directly.
- `_withdrawNft` removes liquidity and mints a **new** NFT to the recipient. It does not return an unchanged original NFT.
- `_claimKyberRewards` may withdraw from mining, synchronize fee growth, burn owed reinvestment tokens, and redeposit. This is live management, unlike FeeStrip's frozen-liquidity/no-interim-touch period.
- Its `onERC721Received` accepts every callback. For FeeStrip, use an expected-deposit context and canonical manager check so arbitrary unsolicited NFTs do not become valid series collateral.

**Reuse:** the idea of reading NFT metadata from the canonical manager, binding immutable range and pool, and settling old rewards at admission. **Rewrite:** all liquidity mutations, mining custody, merging, new-NFT withdrawal, Kyber fee mechanics, and permissive receiver handling.

The meaningful FeeStrip distinction is therefore a tightly defined exposure: the native USDC swap-fee leg of an unchanged individual Uniswap v4 NFT over an exact historical block window, with original-NFT return, separately secured pending-proof proceeds, and cum-income fungible claims. It is a product/design distinction, not a worldwide originality finding.

## Pricing and router boundaries

[PendleMarketV7.sol][market] holds SY and PT, not a standalone YT/USDC inventory. `swapExactPtForSy` and `swapSyForExactPt` calculate transfers, write state, call back, and verify received-token balances against recorded reserves. This is a useful example of checking economic completion after an external callback. Raw token donations do not overwrite recorded market reserves; `skim` sends excess to treasury under Pendle's rules.

[ActionSwapYTV3.sol][swapyt] and [ActionBase.sol][action] turn SY/YT transactions into PT/SY market operations plus mint/redemption callbacks, optionally filling limit orders first. Slippage bounds are checked at the user-facing output boundary. A YT sale is not evidence of a separately funded simple YT pool.

[MarketMathCore.sol][math] uses PT inventory, asset-denominated SY, a logit-based reserve relationship, a maturity-scaled rate scalar, and an implied annual rate. `_getExchangeRateFromImpliedRate` computes exp(r × time-to-expiry); `getMarketPreCompute` and trading reject expiry. This rests on a principal asset to which PT converges.

**Do not port that pricing curve to FeeStrip.** A cum-income fee token approaches its realized USDC entitlement per share at maturity/finalization; it does not approach zero merely because future fee generation has ended, and it has no PT redemption par. Pending historical proof adds uncertainty and liquidity discount, not a mandate that all value decays with time.

For Aqua/SwapVM, a defensible model separates an estimate of the already earned USDC amount per outstanding share, expected remaining window fees, maker inventory skew, spread and uncertainty. The estimate is for quoting, not settlement authority. At/after N, set expected additional window fees to zero and preserve the accrued component. On finalization, the quote can reference the immutable payout pool. Stop or explicitly reprice fills if series state changes during a signed quote's lifetime. Settlement reserves must never be available to an unrelated shared-inventory strategy. This review did not inspect Aqua/SwapVM and makes no claim about their enforcement; these are requirements for that integration.

## Reuse tests and source visibility limits

Neither complete pinned repository tree contains a conventional `test/`, `tests/`, `spec/`, `.t.sol`, `.test.*` or `.spec.*` suite. Both package files expose compilation and formatting scripts, not test scripts. Core's foundry.toml is a special script profile, not a demonstrated test setup. No Pendle dependency install, Solidity compilation, Pendle test suite, live fork or deployment verification was run.

The [ChainSecurity PDF][chainaudit] was downloaded and text-inspected. It is dated 2024-08-15 and identifies public commit 979d55419b65b2565964021f50da25b36acd6d32 plus private commits e01d169859c92b17a70490adefa0b75c754bf9d0 and 48a7abc1a04c5cea927a3c446b7be0f8cc16839f. Its executive scope says base SY, PY V1 and markets V1; derived SY integrations are generally outside scope. Therefore it is not evidence that these current V6/V7 files or the Kyber/Aerodrome adapters were covered at the fetched commits. Other audit PDFs exist in the trees, including marketV6/V7 reports; they were inventoried but not read in this review.

Useful tests to reconstruct from the actual code and report, rather than claim to copy from unavailable tests:

| Test / invariant | Why this source suggests it | Expected FeeStrip result |
|---|---|---|
| Full and partial transfer before/after maturity, including seller exiting entirely | Pendle per-owner accrued bookkeeping | Buyer receives the transferred fraction of all unredeemed series income; seller has no hidden accrued ledger for sold units. |
| Same series under immediate versus arbitrarily delayed proof/collection | First post-expiry Pendle snapshot differs from exact history | The N-window entitlement is identical; only captured later LP fees differ. |
| Wrong NFT manager, fake pool key, different ticks, different NFT ID; unsolicited safe transfer | Kyber's canonical factory and tick validation | Reject noncanonical or unrequested collateral and mismatched series identity. |
| Admission after old fees accrue | Kyber's handling of incoming owed rewards | Old fees go to depositor; buyers begin at recorded cleared baseline. |
| Attempt late mint, interim collect, add/remove liquidity, approval/subscriber mutation | Pendle's actively managed Kyber model is unsuitable | Frozen series constraints hold, or mutation is impossible through the escrow API. |
| Duplicate finalization, wrong chain/block root, proof for different pool/ticks | Idempotent Pendle expiry snapshot, but historical proof is new | Repeat identical finalization cannot allocate twice; unrelated proofs never unlock funds. |
| End block swap before/after exact transaction boundary and inclusion/exclusion convention | Timestamp helper does not specify FeeStrip's block semantics | Verified entitlement follows the documented end-of-block N rule exactly. |
| Post-collection NFT return with proof absent; receiver callback reentry | Pendle reserve/transfer and callback boundaries | NFT is returned once only after captured reserve is secured; proof remains submit-able; callbacks cannot drain obligations. |
| USDC reserve mixed with later LP fees, donations or maker inventory | RewardManager's entire-balance assumption | Only proven window fees fund buyers; later fees and arbitrary balances are not double-counted. |
| Different redemption sizes/orders, six-decimal USDC, final small holder | Pendle's directed rounding | Aggregate buyer payouts never exceed final allocation; all allocated dust has a defined owner. |
| Failure/revert in external dependency, stale/mismatched quote, pause scope | Report's oracle/expiry and pause findings; source external-calling hooks | Plain token transfer and settled claims have the chosen liveness; quoting failure cannot change fee allocation. |

ChainSecurity sections 8.8 (prefund-and-consume atomicity), 8.3 (front-running external reward updates), 6.1 (same-block cached/current index mismatch), 6.2 (oracle path after expiry) and 7.3 (excluded self-address reward shares) are useful scenario prompts. Their relevance is test inspiration, not evidence these issues remain in the reviewed current source.

Five small Python semantic experiments were actually executed, with results in `semantic_experiments_results.json`: seller-held Pendle accrual, exact-versus-late snapshot difference, max-clamped declining exchange rate, finalized-pool redemption conservation, and shared-balance versus series-reserve separation. They pass their model assertions. They are not EVM tests, deployed contract validation or a security proof.

## License and code borrowing

Every Solidity file actually retrieved in this review has **SPDX GPL-3.0-or-later**, including the token/interest/market/router files and all listed adapters. `source_files.json` gives the per-file evidence; imported dependencies were not all fetched and their licenses must be checked separately.

Repository metadata is inconsistent with those labels:

- Core [LICENSE][license] is a short 891-byte BSL-parameter document naming a 2023-07-01 change date and GNU GPL v2.0-or-later as its change license. The file itself appears incomplete: its terms jump from the opening grant fragment to clauses 3 and 4. The retrieved bytes match its Git blob.
- Both [core package.json][corepackage] and [SY package.json][sypackage] say BUSL-1.1; [SY README][syreadme] also says BUSL-1.1.
- The SY tree does not include a root LICENSE file.

Treat this as **specific source reuse under identified file labels with a metadata caveat**, not “all Pendle code is permissive.” For a GPL-compatible open-source prototype, the reviewed files are plausible borrowing candidates when notices, license requirements and dependency licensing are preserved. If the intended repository must be MIT-only/proprietary, copy the ideas and design independent small components rather than paste GPL-labeled Pendle implementations; clarify the contradictory repository metadata with the owner before material direct copying. No legal opinion or complete dependency-license determination is made here.

The best initial reuse choice is architectural inspiration plus very limited compatible helpers, not a Pendle fork: FeeStrip deliberately does not need most of the code that makes Pendle complex.

[yt]: https://github.com/pendle-finance/pendle-core-v2-public/blob/f24265966bb53f75d834ad705decde8e479d3a33/contracts/core/YieldContracts/PendleYieldToken.sol
[pt]: https://github.com/pendle-finance/pendle-core-v2-public/blob/f24265966bb53f75d834ad705decde8e479d3a33/contracts/core/YieldContracts/PendlePrincipalToken.sol
[interest]: https://github.com/pendle-finance/pendle-core-v2-public/blob/f24265966bb53f75d834ad705decde8e479d3a33/contracts/core/YieldContracts/InterestManagerYT.sol
[rewardabstract]: https://github.com/pendle-finance/pendle-core-v2-public/blob/f24265966bb53f75d834ad705decde8e479d3a33/contracts/core/RewardManager/RewardManagerAbstract.sol
[erc20]: https://github.com/pendle-finance/pendle-core-v2-public/blob/f24265966bb53f75d834ad705decde8e479d3a33/contracts/core/erc20/PendleERC20.sol
[factory]: https://github.com/pendle-finance/pendle-core-v2-public/blob/f24265966bb53f75d834ad705decde8e479d3a33/contracts/core/YieldContracts/PendleYieldContractFactoryUpg.sol#L104-L165
[mini]: https://github.com/pendle-finance/pendle-core-v2-public/blob/f24265966bb53f75d834ad705decde8e479d3a33/contracts/core/libraries/MiniHelpers.sol
[action]: https://github.com/pendle-finance/pendle-core-v2-public/blob/f24265966bb53f75d834ad705decde8e479d3a33/contracts/router/base/ActionBase.sol
[market]: https://github.com/pendle-finance/pendle-core-v2-public/blob/f24265966bb53f75d834ad705decde8e479d3a33/contracts/core/Market/PendleMarketV7.sol#L162-L255
[swapyt]: https://github.com/pendle-finance/pendle-core-v2-public/blob/f24265966bb53f75d834ad705decde8e479d3a33/contracts/router/ActionSwapYTV3.sol
[math]: https://github.com/pendle-finance/pendle-core-v2-public/blob/f24265966bb53f75d834ad705decde8e479d3a33/contracts/core/Market/MarketMathCore.sol
[sybase]: https://github.com/pendle-finance/Pendle-SY-Public/blob/73676d931102a369a978a713abfd0b48e3e34361/contracts/core/StandardizedYield/SYBase.sol
[syrewards]: https://github.com/pendle-finance/Pendle-SY-Public/blob/73676d931102a369a978a713abfd0b48e3e34361/contracts/core/StandardizedYield/SYBaseWithRewards.sol
[rewardmanager]: https://github.com/pendle-finance/Pendle-SY-Public/blob/73676d931102a369a978a713abfd0b48e3e34361/contracts/core/RewardManager/RewardManager.sol
[erc4626]: https://github.com/pendle-finance/Pendle-SY-Public/blob/73676d931102a369a978a713abfd0b48e3e34361/contracts/core/StandardizedYield/implementations/PendleERC4626SY.sol
[balancer]: https://github.com/pendle-finance/Pendle-SY-Public/blob/73676d931102a369a978a713abfd0b48e3e34361/contracts/core/StandardizedYield/implementations/BalancerStable/base/PendleAuraBalancerStableLPSYV2.sol
[curve]: https://github.com/pendle-finance/Pendle-SY-Public/blob/73676d931102a369a978a713abfd0b48e3e34361/contracts/core/StandardizedYield/implementations/Curve/PendleCurvePool2TokenSYUpg.sol
[aero]: https://github.com/pendle-finance/Pendle-SY-Public/blob/73676d931102a369a978a713abfd0b48e3e34361/contracts/core/StandardizedYield/implementations/Aerodrome/PendleAerodromeVolatileSY.sol
[kybersy]: https://github.com/pendle-finance/Pendle-SY-Public/blob/73676d931102a369a978a713abfd0b48e3e34361/contracts/core/StandardizedYield/implementations/Kyber/PendleKyberElasticSYUpg.sol
[kyberbase]: https://github.com/pendle-finance/Pendle-SY-Public/blob/73676d931102a369a978a713abfd0b48e3e34361/contracts/core/StandardizedYield/implementations/Kyber/KyberNftManagerBaseUpg.sol
[chainaudit]: https://github.com/pendle-finance/pendle-core-v2-public/blob/f24265966bb53f75d834ad705decde8e479d3a33/audits/main%20codebase/ChainSecurity-2024/ChainSecurity.pdf
[license]: https://github.com/pendle-finance/pendle-core-v2-public/blob/f24265966bb53f75d834ad705decde8e479d3a33/LICENSE
[corepackage]: https://github.com/pendle-finance/pendle-core-v2-public/blob/f24265966bb53f75d834ad705decde8e479d3a33/package.json
[sypackage]: https://github.com/pendle-finance/Pendle-SY-Public/blob/73676d931102a369a978a713abfd0b48e3e34361/package.json
[syreadme]: https://github.com/pendle-finance/Pendle-SY-Public/blob/73676d931102a369a978a713abfd0b48e3e34361/README.md
