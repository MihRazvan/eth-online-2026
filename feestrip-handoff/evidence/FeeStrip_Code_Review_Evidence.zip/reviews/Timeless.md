# Timeless code reading memo

Reviewed 2026-09-11. Source: `timeless-fi/timeless`, commit `47c79493120c562ac69eff786f0445e8b8c9470a` (2022-09-07). Historical implementation; this source review does not establish current usage or liquidity. Downloaded pinned source; read contracts and selected tests; did not execute its suite.

## Transferable patterns

- `src/Gate.sol::_enter` issues matching NYT/PYT amounts; `_exit` accrues yield and burns matching NYT/PYT amounts before withdrawal. Useful rights-conservation pattern: FeeStrip could allow voluntary early closure only when the caller owns the residual NFT right and every outstanding fee claim. It must consume all rights atomically. Timeless itself operates fungible perpetual vault claims, not fixed-term LP NFTs.
- `src/Factory.sol::deployYieldTokenPair` and `_computeYieldTokenAddress` use CREATE2 with constructor arguments binding gate/vault. FeeStrip can derive deterministic series addresses from fully specified economic terms and version. Registry validation must accompany predictability: a deterministic address is not a trusted listing by itself.
- `src/gates/ERC4626Gate.sol::_depositIntoVault` approves only the amount being deposited and clears leftover allowance; comments explicitly treat the vault as untrusted. Apply bounded authority at all router/adapter boundaries. Use maintained token libraries, not a wholesale copy of old custom ERC20 plumbing.
- `src/gates/ERC4626Gate.sol` separates conversions by rounding direction and distinguishes preview/convert functions. The reusable lesson is explicit rounding and economic units; these ERC4626 conversion functions cannot measure raw concentrated-liquidity swap fees.

## Semantics to avoid copying

- `src/PerpetualYieldToken.sol::transfer/transferFrom` calls `Gate.beforePerpetualYieldTokenTransfer` before balances change. Gate stores `userAccruedYield` for both holders; old earned income stays with the previous owner. FeeStrip's unredeemed period income must travel with its ERC20 claim. A normal ERC20 plus final series-wide reserve is the closer design.
- `Gate._computeYieldPerToken` measures positive vault-share price changes, with per-user/per-vault checkpoint state. FeeStrip measures fixed-liquidity native Uniswap fee-growth over a bounded window. There is no expiration/proof mechanism here to port.
- `ownerActivateEmergencyExitForVault` lets an owner set a PYT/NYT split price for single-sided exits. FeeStrip should not introduce discretionary administrative repricing of sold fees. Post-maturity NFT return and retained fee reserve provide a different, narrower recovery structure.
- Timeless clips selected withdrawals to share balances to accommodate rounding. FeeStrip must explicitly validate reserve backing and use a documented integer redemption rule, not silently treat a material shortfall as rounding.

## Tests worth adapting

Read `src/test/base/BaseGateTest.sol` and `src/test/gates/ERC4626Gate.t.sol`:

- `test_transferPYT_toInitializedAccount` and `test_transferPYT_toUninitializedAccount` explicitly check previous-holder accrual. Reuse the scenario, invert the expected ownership to match FeeStrip's whole-period claims.
- `test_transferPYT_selfTransfer`, `test_transferFromPYT_selfTransfer`: self-transfers preserve supply and balances. Source comments in the token warn that cached balance writes would otherwise allow free minting. FeeStrip should avoid bespoke transfer hooks entirely.
- `test_exitToUnderlying`, `test_exitToVaultShares`: complete rights must be consumed for collateral exits.
- `test_cannotActivateEmergencyExit_withoutAuth` and `testFail_cannotCallPYTTransferHook`: negative authority tests are useful even where FeeStrip uses different permissions.
- Fuzzed decimals, deposit sizes and rounding tolerance provide scenario inspiration, but FeeStrip's integer USDC payouts should be asserted exactly against a rational reference model and its specified rounding rule.

## License and evidence boundary

Root license and reviewed core headers say AGPL-3.0. Preserve attribution and applicable source obligations if copying. Individual dependencies have their own terms. Timeless docs link a Spearbit audit, but audit scope was not mapped to this pin in this pass; no audit assurance is asserted for FeeStrip.

Pinned reading links:

- https://github.com/timeless-fi/timeless/blob/47c79493120c562ac69eff786f0445e8b8c9470a/src/Gate.sol
- https://github.com/timeless-fi/timeless/blob/47c79493120c562ac69eff786f0445e8b8c9470a/src/Factory.sol
- https://github.com/timeless-fi/timeless/blob/47c79493120c562ac69eff786f0445e8b8c9470a/src/PerpetualYieldToken.sol
- https://github.com/timeless-fi/timeless/blob/47c79493120c562ac69eff786f0445e8b8c9470a/src/gates/ERC4626Gate.sol
- https://github.com/timeless-fi/timeless/blob/47c79493120c562ac69eff786f0445e8b8c9470a/src/test/base/BaseGateTest.sol
