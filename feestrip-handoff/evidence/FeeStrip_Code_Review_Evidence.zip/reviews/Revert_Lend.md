# Revert Lend code review for FeeStrip

Research date: 2026-09-11. This is a source-reading pass, not an audit or deployment attestation.

## Pins and examined scope

- Revert Lend main: [`7e85a81ac97663a3a731f6d6f07f14d774962a6e`](https://github.com/revert-finance/lend/commit/7e85a81ac97663a3a731f6d6f07f14d774962a6e), committed 2026-07-05, “Fix AutoRange vault transform cleanup (#60).” This was the latest main revision returned by the GitHub API during this pass.
- The complete textual source tree at this pin is under `source/`; submodule commit IDs are in `pin.json`. Submodules were not materialized.
- Examined `V3Vault`, `V3Oracle`, `Transformer`, `AutoRange`, `AutoCompound`, `Automator`, `Swapper`, relevant `V3Utils` paths, integration tests, README, deployment-fix runbook, LICENSE, and historical C4 report.
- [C4 report source](https://github.com/code-423n4/2024-03-revert-lend-findings/blob/5fd5466a646d1870367733b8c2bf352af5f9298d/report.md), pinned at `5fd5466a646d1870367733b8c2bf352af5f9298d`. The 2024 audited source is different from this 2026 main revision; historical findings below are not allegations against current main.
- [Current official security index](https://docs.revert.finance/revert/resources/security) links Hydn, Code4rena and PeckShield work for Lend/automators. Their presence does not establish coverage of the 2026 pin. Aerodrome/GaugeManager is a separate branch and was not reviewed here.
- Tests were inspected, not executed. No live deployed bytecode was checked.

## Decision

Revert is a useful reference for NFT custody boundaries, intent-bound callbacks, explicit residual-token ledgers, and separating asset return from mandatory accounting. Its purpose is to keep collateral actively manageable. FeeStrip's purpose requires a much narrower custody contract: after old fees are cleared, freeze the canonical hookless v4 NFT's pool identity, range and liquidity; forbid harvesting throughout the term; capture all accrued native fees after block N before releasing the NFT; hold the captured reserve while the historical proof arrives.

Do not port the lending core, its transformer authority, its mutable position automation, or its valuation oracle into a fee-sale escrow. Aqua/SwapVM trading should receive authority over maker-held strip-token inventory only.

## Code map and useful patterns

| Source at pinned commit | Actual behavior | FeeStrip adaptation |
|---|---|---|
| [V3Vault.create / createWithPermit / onERC721Received](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/src/V3Vault.sol#L429-L503) | Pulls the NFT from caller; receiver admits only its immutable NPM and rejects self-sends. Direct safe transfers can establish a beneficiary from callback data. | Admit only the canonical v4 PositionManager. Bind intake to an expected NFT, depositor, beneficiary, pool key, immutable term, and active creation operation. Verify final custody. A canonical sender check alone is weaker than complete operation binding. |
| [V3Vault.transform](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/src/V3Vault.sol#L523-L574) | Requires global transformer allowlist plus owner/caller approval; records active token; approves transformer; makes external call; verifies returned NFT custody; clears approval on final NFT; checks loan health; clears active token. | Borrow explicit operation context, final custody checks, and postconditions. Replace “healthy collateral value” with exact unchanged pool/range/L and zero term harvesting. Do not retain arbitrary transformer calls. |
| [Transformer._validateCaller](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/src/transformers/Transformer.sol#L50-L65) | A configured vault must name its currently transformed NFT. A direct caller must own the NFT, or the transformer itself must own it. | Bind inner callback arguments to the outer operation. Approval of an adapter is not authorization for arbitrary callers to choose another NFT or recipient. |
| [V3Vault._cleanupLoan / remove](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/src/V3Vault.sol#L1165-L1172) and [remove](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/src/V3Vault.sol#L810-L827) | Cleanup clears debt/accounting while keeping NFT custody; owner later removes an eligible NFT. Owner mapping is updated before safe transfer. | Separate fee capture, proof acceptance, buyer redemption, and NFT withdrawal. A reverting NFT receiver must not prevent reserve capture or proof settlement. Return eligibility requires completed native-fee capture; proof may remain pending. |
| [AutoCompound.positionBalances and withdrawal paths](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/src/transformers/AutoCompound.sol#L47-L49), [withdrawals](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/src/transformers/AutoCompound.sol#L203-L250), [ledger debit](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/src/transformers/AutoCompound.sol#L263-L290) | Tracks leftovers per NFT and ERC20; token ID zero is protocol reward balance. Withdrawals debit ledger before token transfer and use reentrancy protection. | Use explicit liabilities per series/currency, with separate buyer reserve, post-N LP reserve, protocol revenue, and paid totals. Retain liabilities after NFT return. Do not infer series ownership of funds from raw contract balances. |
| [Swapper._routerSwap](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/src/utils/Swapper.sol#L69-L113) | Uses before/after input/output balances and output minimum; temporary 0x allowance is cleared after call. | Balance deltas are a useful capture/accounting check, subject to supported-token assumptions. Custody reserve does not need a swap router or route approvals. |
| [Swapper.uniswapV3SwapCallback](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/src/utils/Swapper.sol#L148-L168) | Authenticates callback by recomputing canonical pool from token pair/fee/factory. | Carry the authentication principle into v4's different PoolManager/PositionManager action model, including expected active operation; v3 callback signatures and pool addressing are not portable. |
| [V3Oracle.getLiquidityAndFees](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/src/V3Oracle.sol#L177-L192) and [fee-growth math](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/src/V3Oracle.sol#L507-L566) | Native fee amounts can be read without dollar valuation. Computes inside growth from global/outside counters and current tick, uses modular subtraction and full-precision multiply/divide, then adds NPM owed balances. | Separate native settlement math from price-display analytics. Reimplement against exact v4 pool state/position semantics and prove the historical state at N. TWAP and Chainlink cannot establish historical fee ownership. |

## The strongest authority-cleanup lesson

The latest patch is especially relevant because it shows why “revoke on completion” must cover every asset that was authorized, not just the asset returned from the operation.

During AutoRange replacement, the old NFT stays vault-owned but debt-free. `V3Vault.transform` clears approval on `newTokenId`, which can differ from the originally approved NFT. The regression test explicitly asserts that the old NFT remains approved to AutoRange and the new NFT has zero approval. The fix is in AutoRange's execution guard: direct operators cannot execute against a configured vault-owned NFT, even if ERC721 approval remains. Calls must flow through the vault's active transformation context.

Evidence:
- [AutoRange._validateExecutionCaller](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/src/transformers/AutoRange.sol#L519-L529)
- [testTransformAutoRangeInsideVault](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/test/integration/V3Vault.t.sol#L549-L615)
- [replacement deployment runbook](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/script/DEPLOY_AUTORANGE_FIX.md)

The runbook requires deploying a new AutoRange and separately updating the vault allowlist; this is further reason not to assume latest source equals deployed code. Removing an address from a vault allowlist is also not, by itself, revocation of an ERC721 approval already stored in the NFT contract.

FeeStrip should have no replacement route during an active series and no enduring approval to automators, routers, trading contracts or keepers. Keep one immutable NFT identity. A keeper's authority should be “trigger this predetermined capture after N,” with recipient and all manager actions constructed by the escrow. Test the actual manager's approvals, operator approvals and supported permit paths; testing only FeeStrip's own role mapping misses residual authority.

## What must not cross into FeeStrip

1. **Debt/health checks.** `borrow` can defer health checks during an active allowed transformation; `decreaseLiquidityAndCollect` lets an owner withdraw fees and principal if health remains sufficient; `transform` accepts an entirely different final NFT. These are deliberate lending features. A zero-debt loan being healthy does not protect purchased fees or fixed L. See [borrow and withdraw collateral](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/src/V3Vault.sol#L579-L679), [health predicate](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/src/V3Vault.sol#L1365-L1374).

2. **Active management.** [AutoRange.execute](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/src/transformers/AutoRange.sol#L133-L313) removes all liquidity, harvests, may swap, creates a new range/NFT, returns leftovers to the beneficial owner, and migrates config. [AutoCompound.execute](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/src/transformers/AutoCompound.sol#L103-L200) collects fees and increases L. Both destroy FeeStrip's fixed-term accounting assumptions.

3. **Raw-balance sweep administration.** The base [Automator.withdrawBalances / withdrawETH](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/src/automators/Automator.sol#L86-L128) can withdraw entire token/native balances. AutoCompound overrides ERC20 withdrawal to use its reward ledger. Port the explicit-liability approach, never an unrestricted balance sweep across buyer reserves.

4. **Virtual lending reserves and ERC4626 shares.** [V3Vault._getBalanceAndReserves](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/src/V3Vault.sol#L1109-L1118) derives reserves from liquid assets plus debt minus lender claims. FeeStrip needs fully captured native assets backing the pending proof and redemption claims. Its fixed ERC20 quantity should not use a changing interest exchange rate or debt-backed reserve.

5. **Value oracle as settlement oracle.** [V3Oracle._populatePrices](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/src/V3Oracle.sol#L475-L494) cross-checks pool spot and external derived prices, potentially reverting when they diverge. [Chainlink](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/src/V3Oracle.sol#L347-L385) validates age, positive answer, and optional sequencer state; [TWAP](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/src/V3Oracle.sol#L399-L421) reads observations and rounds negative tick means downward. These concerns belong to current value protection. FeeStrip's consensus-bound block-N fee growth is a different trust boundary; no price health check should gate native reserve accounting or NFT return.

6. **Broad ERC20 allowances.** [AutoCompound._checkApprovals](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/src/transformers/AutoCompound.sol#L293-L302) grants maximum allowances to its NPM. This gas optimization is inappropriate for unrelated trading systems to hold over a fee reserve. `SafeERC20` alone also does not make fee-on-transfer/rebasing currencies compatible with exact accounting. Restrict supported behavior or verify actual received amounts and solvency explicitly.

## Historical audit lessons, with current-source checks

The [2024 report](https://github.com/code-423n4/2024-03-revert-lend-findings/blob/5fd5466a646d1870367733b8c2bf352af5f9298d/report.md) records missing Permit2 token binding (H-01), receiver callback accounting/liveness failures (H-02/H-06), and mismatched or missing transformer caller validation (H-03/H-04). These are useful negative tests, not current vulnerability claims.

At this pin, `_deposit`, `_repay` and liquidation check `permit.permitted.token == asset`; `Transformer._validateCaller` binds vault execution to the active NFT; `V3Utils.execute` invokes that validation; cleanup leaves NFT withdrawal separate. The current [testTransformExploit](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/test/integration/V3Vault.t.sol#L1323-L1359) tries to operate on Alice's externally approved NFT while Bob authenticates using his own vault NFT and expects failure.

The design lesson is to bind the asset, operation and beneficiary, and keep mandatory accounting independent of beneficiary-controlled callbacks.

## FeeStrip settlement boundary

Use distinct state for reserve capture, proof resolution, NFT return and token redemption. The economically necessary ordering is:

1. At creation, atomically clear old fees to the LP, verify the fixed pool/range/L and establish the immutable start fee-growth baseline. Mint fixed supply only after successful custody/baseline establishment.
2. Throughout the term through its specified block-N cutoff, no collection, liquidity mutation, NFT replacement, approval grant or owner escape.
3. At a strictly valid post-cutoff capture point K, collect **all** native fees then available without removing principal, verify the manager operation and actual per-currency receipt, and record the captured reserve. This is mandatory before enabling NFT return.
4. Return the same NFT independently of the historical proof. Any future use of the returned NFT cannot remove already captured reserves or erase the immutable historical identity/baseline.
5. Authenticate pool state at N. Compute buyer term fees from the agreed baseline and historical inside growth, using fixed L and correct rounding. For each currency, require buyer allocation no greater than captured reserve; the remainder of that reserve belongs to the LP as late fees under the specified rounding policy. Do not release an estimated “late” portion while proof is pending.
6. Buyers redeem by burning strip units; a transfer carries all remaining full-period entitlement. Do not introduce an in-term harvest/distribution checkpoint that leaves already-earned fees with an earlier holder.

The separation should survive a proof outage: assets remain reserved and the NFT can be returned after capture, but the unresolved reserve is not withdrawn by governance or assumed to belong to the LP. The proof verifier, chain, block number/hash, manager address, pool key, tick bounds, state layout/version and finality policy need explicit binding.

## Concrete test plan for FeeStrip

These are proposed implementation tests; they were not run in this review.

| Test / invariant | Adversarial sequence and expected result |
|---|---|
| Canonical intake plus expected operation | Invoke receiver directly; send a lookalike NFT; send a different canonical NFT during the wrong operation; spoof callback data/beneficiary. No series mints or liability changes. Valid intake yields the exact expected token in escrow. |
| Approve-then-front-run | LP approves creation adapter; attacker submits creation for that NFT or alters recipients/terms. Fail unless a verified intent explicitly authorizes the exact complete action. |
| Cross-position callback confusion | Series A action carries series B's NFT/pool/currency IDs inside callback data. Reject even when both use an approved manager. No reserve or custody movement for B. |
| Immutable position during term | Randomly call every public manager/escrow/adapter/permit/operator path to collect, burn, increase/decrease L, change range, replace or transfer the NFT. Every successful active-term transition preserves NFT identity, pool/range/L and the stored baseline. Include permissionless top-up attempts against the actual v4 manager. |
| No residual authority | After creation and after capture, assert no unexpected per-token approval, operator permission, permit-enabled spend route or approval on an old/replaced ID. Governance/keeper/Aqua/SwapVM cannot mutate the NFT or spend reserves. |
| Old-fee exclusion | Mint positions with both accrued and previously-accounted fees. Create series, then capture. Pre-start fees paid to the LP never enter buyer liabilities; baseline is taken after the creation fee-clearing operation. |
| Correct block boundary | Swap before/at/after N; capture at N+1 and much later. Buyer allocation is identical for the same canonical N state; only captured late LP fees change. Define end-of-block versus any transaction-local boundary explicitly. |
| Historical inside-growth branches | N tick below lower, equal lower, inside, equal upper, above upper; later price elsewhere; counters near uint256 wrap. Historical branch selection uses N's tick. Rounding/counter semantics match canonical v4 code. |
| Principal preservation | Capture via the intended zero-liquidity fee action. Verify unchanged L, range and NFT; no positive-liquidity decrease can be disguised as fees. Per-currency deltas agree with the manager operation within precisely specified rounding. |
| Return before proof | Capture, return NFT, transfer/reconfigure/use it outside escrow, then submit valid N proof. Buyer settlement is identical and reserve remains fully available. Attempt return before capture must fail. |
| Receiver and token callback liveness | Use an LP receiver that reverts/reenters on NFT return. Reserve capture/proof resolution remains independently callable. Use adversarial token callbacks at payouts; liabilities are debited once and unrelated series remain untouched. |
| Reserve conservation and segregation | For every supported currency, actual controlled assets cover aggregate unpaid buyer + unpaid late LP + separately earned protocol liabilities. Donations, another series' funds and maker-wallet inventory cannot substitute for missing capture. Asset receipts, allocations and payouts reconcile without double counting. |
| Proof binding and one-time resolution | Reject wrong chain/block hash/pool/manager/range/state slot/series, malformed or noncanonical proofs, wrong finality, duplicate proofs, and proof producing allocation above reserve. A returned NFT does not invalidate correctly retained series identity. |
| All rights travel | A owns all strip tokens; fees accrue; A transfers to B before proof; B receives full period entitlement on redemption. Transfer at N, after capture and after proof also carries all unredeemed rights. A retains no checkpointed pre-transfer claim. |
| Fixed supply / rounding / double redemption | No mint after creation; every redemption burns amount once; randomized transfers and fragmented redemptions cannot exceed either reserve. Explicit dust policy covers the final unit/last redeemer and cannot be exploited by order or splitting. |
| Restricted administration | All role changes, emergency paths and rescue calls preserve immutable series terms and unpaid reserves. Pausing creation/trading cannot become a discretionary haircut or prerequisite for fee capture/NFT return. |

A useful core accounting assertion after proof, per series and currency, is: total captured = fixed buyer allocation + fixed late-LP allocation; each fixed allocation = paid amount + unpaid liability (with any dust explicitly assigned). Before proof, all captured assets remain encumbered. Cross-series solvency is checked separately from individual series accounting.

## Test evidence and reproducibility limits

- [V3Vault.t.sol](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/test/integration/V3Vault.t.sol) covers borrowing, repayment, range transformations, compounding in/out of vault, liquidations, reserve paths, Permit2, parameter fuzzing, and the cross-NFT transform regression. `testBasicsFuzz` has an explicit 1,024-run directive; this is a sequential parameter-fuzz test, not evidence of a handler-based invariant campaign.
- [V3Oracle.t.sol](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/test/integration/V3Oracle.t.sol) covers price conversions/configuration, oracle errors, and price divergence. [AutoRange tests](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/test/integration/automators/AutoRange.t.sol) exercise authorization, config, adjustment eligibility, repeated adjustment and oracle checks. [AutoCompound tests](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/test/integration/automators/AutoCompound.t.sol) check lack of access/approval, residual balances and both swap directions.
- No `invariant_` entrypoints were found in the downloaded test tree. Do not equate named fuzz tests or historical audits with FeeStrip invariant coverage.
- Tests depend on mainnet/Polygon forks; V3Vault/V3Oracle mainnet setup uses block 18,521,658; automator base uses 15,489,169. An `ANKR_API_KEY` was not available in this runtime.
- [README](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/README.md#L17-L31) requires a v3-periphery init-code-hash adjustment for mainnet integration/deployment. [foundry.toml](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/foundry.toml) pins solc 0.8.24. No upstream compile or test pass is claimed.

## License

Core Solidity files retain `BUSL-1.1` SPDX identifiers. The pinned [LICENSE](https://github.com/revert-finance/lend/blob/7e85a81ac97663a3a731f6d6f07f14d774962a6e/LICENSE) names Revert Labs, gives a change date of the earlier of 2026-06-01 or a specified date, and names GPL v2.0 or later as the change license. The stated fixed date has passed at this review date. This is not an MIT codebase; preserve notices and evaluate the actual per-version change-license obligations before code reuse. The recommended FeeStrip work is an independent narrow implementation of the safety patterns, verified against canonical v4 semantics.

