// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;
import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "resonate/hardhat/contracts/SmartWallet.sol";
contract ReserveToken is ERC20 {
    constructor() ERC20("reserve", "R") {}
    function mint(address to,uint amount) external {_mint(to,amount);}
    function burn(address from,uint amount) external {_burn(from,amount);}
}
contract MockShareVault is ERC20 {
    ReserveToken public reserve;
    constructor() ERC20("shares","S") {reserve=new ReserveToken();}
    function seed(address user,uint amount) external {_mint(user,amount);reserve.mint(address(this),amount);}
    function addYield(uint amount) external {reserve.mint(address(this),amount);}
    function lose(uint amount) external {reserve.burn(address(this),amount);}
    function previewWithdraw(uint amount) public view returns(uint) {
        if(amount==0)return 0;
        return (amount*totalSupply()+reserve.balanceOf(address(this))-1)/reserve.balanceOf(address(this));
    }
    function withdraw(uint amount,address to,address from) external returns(uint shares) {
        require(msg.sender==from); shares=previewWithdraw(amount);_burn(from,shares);reserve.transfer(to,amount);
    }
    function redeem(uint shares,address to,address from) external returns(uint amount) {
        require(msg.sender==from);amount=shares*reserve.balanceOf(address(this))/totalSupply();_burn(from,shares);reserve.transfer(to,amount);
    }
}
contract ResonateSmokeTest {
    MockShareVault vault;
    ResonateSmartWallet wallet;
    function setUp() public {
        vault=new MockShareVault();wallet=new ResonateSmartWallet(address(this));vault.seed(address(wallet),1000 ether);
    }
    function testPrincipalReleasePreservesIncomeReceiptReserve() public {
        vault.addYield(100 ether);
        uint residual=wallet.reclaimPrincipal(address(vault),address(1),1000 ether,1000 ether,true);
        require(vault.reserve().balanceOf(address(1))==1000 ether);
        require(residual==vault.balanceOf(address(wallet))&&residual>0);
        (uint income,)=wallet.reclaimInterestAndResidual(address(vault),address(2),0,0,residual);
        require(income==100 ether);
    }
    function testResidualSharesContinueEarningUntilIncomeRedemption() public {
        vault.addYield(100 ether);
        uint residual=wallet.reclaimPrincipal(address(vault),address(1),1000 ether,1000 ether,true);
        vault.addYield(10 ether);
        (uint income,)=wallet.reclaimInterestAndResidual(address(vault),address(2),0,0,residual);
        require(income==110 ether,"reserve is yield-bearing shares, no historical cutoff");
    }
    function testPrincipalShortfallRedeemsOnlyAssignedShares() public {
        vault.lose(500 ether);
        uint residual=wallet.reclaimPrincipal(address(vault),address(1),1000 ether,1000 ether,true);
        require(residual==0);
        require(vault.reserve().balanceOf(address(1))==500 ether);
    }
}
