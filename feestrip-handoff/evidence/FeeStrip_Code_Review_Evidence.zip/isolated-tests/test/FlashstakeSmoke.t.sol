// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;
import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "flash/contracts/strategies/FlashStrategyAAVEv2.sol";
import "flash/contracts/FlashFToken.sol";

contract MockToken is ERC20 {
    constructor() ERC20("Mock", "MOCK") {}
    function mint(address to, uint amount) external { _mint(to,amount); }
    function burn(address from, uint amount) external { _burn(from,amount); }
}
contract MockPool {
    MockToken public principal;
    MockToken public atoken;
    constructor(MockToken p,MockToken a) {principal=p;atoken=a;}
    function deposit(address,uint amount,address onBehalfOf,uint16) external {
        require(principal.transferFrom(msg.sender,address(this),amount));
        atoken.mint(onBehalfOf,amount);
    }
    function withdraw(address,uint amount,address to) external returns(uint) {
        atoken.burn(msg.sender,amount);
        require(principal.transfer(to,amount));
        return amount;
    }
    function addYield(address target,uint amount) external {
        principal.mint(address(this),amount); atoken.mint(target,amount);
    }
}
contract FlashstakeSmokeTest {
    MockToken principal;
    MockToken atoken;
    MockPool pool;
    FlashStrategyAAVEv2 strategy;
    FlashFToken ftoken;
    function setUp() public {
        principal=new MockToken(); atoken=new MockToken();
        pool=new MockPool(principal,atoken);
        strategy=new FlashStrategyAAVEv2(address(pool),address(principal),address(atoken),address(this));
        ftoken=new FlashFToken("fMock","fMOCK");
        strategy.setFTokenAddress(address(ftoken));
        principal.mint(address(strategy),1000 ether);
        strategy.depositPrincipal(1000 ether);
        ftoken.mint(address(this),100 ether);
        ftoken.approve(address(strategy),type(uint).max);
    }
    function testNoYieldMeansNoUpfrontCash() public {
        require(strategy.getYieldBalance()==0);
        (bool ok,) = address(strategy).call(abi.encodeCall(strategy.burnFToken,(10 ether,0,address(this))));
        require(!ok,"zero-yield burn must fail");
        require(ftoken.balanceOf(address(this))==100 ether);
    }
    function testMintingAnotherCohortDilutesLiveQuote() public {
        pool.addYield(address(strategy),100 ether);
        require(strategy.quoteBurnFToken(10 ether)==10 ether);
        ftoken.mint(address(123),100 ether);
        require(strategy.quoteBurnFToken(10 ether)==5 ether,"live supply changes quote");
    }
    function testMinReturnRevertsAndPreservesState() public {
        pool.addYield(address(strategy),100 ether);
        (bool ok,) = address(strategy).call(abi.encodeCall(strategy.burnFToken,(10 ether,11 ether,address(this))));
        require(!ok,"minimum must be honored");
        require(strategy.getYieldBalance()==100 ether);
        require(ftoken.balanceOf(address(this))==100 ether);
    }
    function testBurnRedeemsCurrentYieldAndKeepsPrincipalReserved() public {
        pool.addYield(address(strategy),100 ether);
        require(strategy.burnFToken(50 ether,50 ether,address(this))==50 ether);
        require(principal.balanceOf(address(this))==50 ether);
        require(strategy.getPrincipalBalance()==1000 ether);
        require(atoken.balanceOf(address(strategy))==1050 ether);
        require(strategy.getYieldBalance()==50 ether);
        strategy.withdrawPrincipal(1000 ether);
        require(strategy.getPrincipalBalance()==0);
        require(strategy.getYieldBalance()==50 ether);
    }
    function testYearMintRateIsApproximateNotExact() public view {
        require(strategy.quoteMintFToken(1 ether,365 days)==1_000_000_000_512_000_000);
    }
    function testLossMakesYieldViewRevertInsteadOfSocializingLoss() public {
        atoken.burn(address(strategy),1);
        (bool ok,) = address(strategy).staticcall(abi.encodeCall(strategy.getYieldBalance,()));
        require(!ok,"balance-minus-principal is checked arithmetic");
    }
}
