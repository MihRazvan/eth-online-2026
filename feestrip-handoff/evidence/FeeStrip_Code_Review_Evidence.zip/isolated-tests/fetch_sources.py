#!/usr/bin/env python3
"""Retrieve exact source dependencies. Requires Python 3.9+ and HTTPS access.
No package manager or upstream installation/build script is invoked.
"""
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile
import urllib.request

ROOT = Path(__file__).resolve().parent
LOCK = json.loads((ROOT / 'source-lock.json').read_text())


def checked_target(destination, relative):
    for value in (destination, relative):
        parts = PurePosixPath(value)
        if parts.is_absolute() or '..' in parts.parts:
            raise ValueError('Unsafe path in source lock: ' + value)
    target = (ROOT / destination / relative).resolve()
    if not target.is_relative_to(ROOT / 'lib'):
        raise ValueError('Source target escapes lib: ' + str(target))
    return target


def fetch_repo(entry):
    repo, sha = entry['repo'], entry['sha']
    if len(sha) != 40 or any(c not in '0123456789abcdef' for c in sha):
        raise ValueError('Expected full lowercase commit SHA')
    files = entry['files']
    if all(checked_target(entry['destination'], name).is_file() and
           hashlib.sha256(checked_target(entry['destination'], name).read_bytes()).hexdigest() == digest
           for name, digest in files.items()):
        print(repo + ': already verified')
        return
    url = 'https://codeload.github.com/' + repo + '/tar.gz/' + sha
    print('Fetching ' + repo + '@' + sha, flush=True)
    request = urllib.request.Request(url, headers={'User-Agent': 'FeeStrip-source-review-harness'})
    with urllib.request.urlopen(request, timeout=90) as response:
        archive = response.read()
    pending = []
    with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as tar:
        members = tar.getmembers()
        roots = {m.name.split('/', 1)[0] for m in members if m.name}
        if len(roots) != 1:
            raise ValueError('Expected one GitHub archive root')
        prefix = next(iter(roots)) + '/'
        for relative, digest in files.items():
            target = checked_target(entry['destination'], relative)
            member = tar.getmember(prefix + relative)
            if not member.isfile():
                raise ValueError('Expected regular source file: ' + relative)
            source = tar.extractfile(member)
            if source is None:
                raise ValueError('Missing archive bytes: ' + relative)
            data = source.read()
            if hashlib.sha256(data).hexdigest() != digest:
                raise ValueError('SHA-256 mismatch: ' + repo + '/' + relative)
            pending.append((target, data))
    for target, data in pending:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    print(repo + ': verified ' + str(len(pending)) + ' files')


if __name__ == '__main__':
    for entry in LOCK['repositories']:
        fetch_repo(entry)
    print('Dependencies ready. Run: forge test -vv')
