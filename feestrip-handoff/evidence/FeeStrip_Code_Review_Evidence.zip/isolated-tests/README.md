# FeeStrip comparator smoke tests

Nine focused tests exercise **unmodified upstream** `FlashStrategyAAVEv2`, `FlashFToken` and `ResonateSmartWallet` contracts. Aave, aToken and ERC4626 behavior is supplied by small local mocks. This is not either project's complete test suite, a fork test, deployed-bytecode verification, or a FeeStrip implementation.

## Reproduce

Prerequisites: Python 3.9+, Foundry (`forge`) and HTTPS access to GitHub. The portable configuration selects Solidity 0.8.26; Foundry may download that compiler if absent. The recorded run used Forge 1.8.1, commit `982849d3140c01fd3b72905759581a132df7aa98`, and Solidity 0.8.26. The compiler satisfies the contracts' pragmas but is not claimed to match upstream deployment settings.

From this directory:

```bash
python3 fetch_sources.py
forge test -vv
```

`fetch_sources.py` downloads commit-pinned GitHub archives and writes only the required Solidity files into `lib/`. It verifies every file against `source-lock.json`, preserves source contents and SPDX notices, and runs no upstream scripts. No wallet, RPC endpoint, environment secret or package-manager installation is required. The bundle excludes dependencies and build output; `lib/`, `out/` and `cache/` can be regenerated. The log from the original nine-test run is `results.txt`.

The portable path configuration and retrieval script were prepared after the recorded test run. They do not change tested contract or harness source. No additional tests were run for this packaging step.

## Exact dependency pins

| Dependency | Commit | Source |
|---|---|---|
| Flashstake core | `8f11e9255fe19c7d15867d13cae32acc958a04ad` | [BlockzeroLabs/flashv3-contracts](https://github.com/BlockzeroLabs/flashv3-contracts/tree/8f11e9255fe19c7d15867d13cae32acc958a04ad) |
| Resonate | `a114ea0b3f462008099076397345359114cfbcd2` | [Revest-Finance/ResonateContracts](https://github.com/Revest-Finance/ResonateContracts/tree/a114ea0b3f462008099076397345359114cfbcd2) |
| OpenZeppelin 4.5.0 | `a5445b0afb8b350417b6e6ab3160554967bc151f` | [OpenZeppelin/openzeppelin-contracts](https://github.com/OpenZeppelin/openzeppelin-contracts/tree/a5445b0afb8b350417b6e6ab3160554967bc151f) |

## What the assertions establish

| Harness | Assertions |
|---|---|
| `FlashstakeSmoke.t.sol` | No upfront cash without pooled yield; added fToken supply dilutes a live quote; caller minimum prevents burn and payout; principal remains reserved during income redemption; annual issuance constant is approximate; loss makes checked yield subtraction revert. |
| `ResonateSmoke.t.sol` | Principal withdrawal preserves residual income shares; those shares continue earning until redemption; a shortfall pays only the available assigned shares. |

The extra-mint and loss scenarios isolate mathematical properties using mock dependencies and test authority. They do not claim permissionless minting or a demonstrated live Aave loss exploit. These behaviors distinguish the comparators from FeeStrip's fixed-supply, exact-block fee entitlement.
