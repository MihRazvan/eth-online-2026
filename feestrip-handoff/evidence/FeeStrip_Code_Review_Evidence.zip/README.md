# FeeStrip comparator code review evidence

Reviewed 11 September 2026. Start with FeeStrip_Competitor_Code_Review.md.

- reviews/: detailed source-reading memos covering six protocols.
- provenance/: repository pins and file manifests recorded during inspection.
- isolated-tests/: nine-test Foundry harness, recorded output, dependency lock and source retrieval script. Read its README before reproducing.
- models/: five Python-only semantic checks and results. These are simplified models, not EVM validation.

Full upstream repositories, auditor PDFs, build output and downloaded dependencies are not bundled. The memos describe the original inspection workspace; retrieve referenced source through their immutable GitHub links. The isolated harness includes a hash-checked retrieval script for its dependencies. No complete upstream test suite, production bytecode match or end-to-end FeeStrip test is claimed.

All code in the harness was created for research before any FeeStrip implementation. If using these planning or test artifacts in a hackathon submission, disclose their timing, sources and AI assistance under the chosen event track rules. Source licenses and audit boundaries are recorded in the guide and detailed memos.
