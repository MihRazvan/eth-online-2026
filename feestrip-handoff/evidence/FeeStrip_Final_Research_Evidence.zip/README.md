FeeStrip final research evidence

The final build brief recommends Uniswap + 1inch + The Graph. Privy is an alternative third partner, not a fourth submission selection.

This archive preserves the final independent source memos, official-document links, and ScopeLift repository pin. ScopeLift tests were inspected, not executed. No live Graph pipeline, integrated FeeStrip contract deployment, or real-chain proof validation was performed in this final pass. Earlier component harnesses remain in the earlier evidence bundles.

Files:
- scopelift.md: direct predecessor, precise source comparison and reuse limits.
- scopelift_pin.json: inspected public repository commit.
- graph.md: Graph bounty qualification, reusable v4 pipeline and provider prerequisites.
- other_bounties.md: alternative partners, Privy implementation and current requirements.
